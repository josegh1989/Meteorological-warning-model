library(mgcv)
#----tm vs um----
#手足口gam
#载入腹泻数据
data_HFMD <- read.csv("D:\\zha\\DLNM\\GAM\\DageHFMD.csv", header = TRUE, sep = ",", quote = "\"")
#年龄变分类项
data_HFMD$AgeGroup <- as.factor(data_HFMD$age)
gam_model1 <- gam(cases ~ s(Tm, Um) + ti(Tm, Um, bs = "tp") + factor(AgeGroup),
                  data = data_HFMD, family = poisson(), select = TRUE)
#模型摘要
#summary(gam_model1)
#创建新data
new_data <- expand.grid(Tm = seq(min(data_HFMD$Tm), max(data_HFMD$Tm), length.out = 100), 
    Um = seq(min(data_HFMD$Um), max(data_HFMD$Um), length.out = 100), AgeGroup = levels(data_HFMD$AgeGroup))
predicted_cases1 <- predict(gam_model1, newdata = new_data, type = "response")
new_data$PredictedCases1 <- predicted_cases1
write.csv(new_data, "D:/zha/DLNM/GAM/predicted_cases_HFMD.csv", row.names = FALSE)

#病毒性腹泻gam
#载入腹泻数据
data_dia <- read.csv("D:\\zha\\DLNM\\GAM\\Dagedia.csv", header = TRUE, sep = ",", quote = "\"")
#年龄变分类项
data_dia$AgeGroup <- as.factor(data_dia$age)
gam_model2 <- gam(cases ~ s(Tm, Um) + ti(Tm, Um, bs = "tp") + factor(AgeGroup), 
                  data = data_dia, family = poisson(), select = TRUE)
#模型摘要
#summary(gam_model)
#创建新data
new_data1 <- expand.grid(Tm = seq(min(data_dia$Tm), max(data_dia$Tm), length.out = 100), 
    Um = seq(min(data_dia$Um), max(data_dia$Um), length.out = 100), AgeGroup = levels(data_dia$AgeGroup))
predicted_cases <- predict(gam_model2, newdata = new_data1, type = "response")
new_data1$PredictedCases <- predicted_cases
write.csv(new_data1, "D:/zha/DLNM/GAM/predicted_cases_dia.csv", row.names = FALSE)

#非病毒性腹泻gam
#载入腹泻数据
data_dia1 <- read.csv("D:\\zha\\DLNM\\GAM\\Dagedianon.csv", header = TRUE, sep = ",", quote = "\"")
data_dia1$AgeGroup <- as.factor(data_dia1$age)
gam_model3 <- gam(cases ~ s(Tm, Um) + ti(Tm, Um, bs = "tp") + factor(AgeGroup), 
                  data = data_dia1, family = poisson(), select = TRUE)
#模型摘要
#summary(gam_model)
#创建新data
new_data2 <- expand.grid(Tm = seq(min(data_dia1$Tm), max(data_dia1$Tm), length.out = 100), 
                         Um = seq(min(data_dia1$Um), max(data_dia1$Um), length.out = 100), AgeGroup = levels(data_dia1$AgeGroup))
predicted_cases <- predict(gam_model3, newdata = new_data2, type = "response")
new_data2$PredictedCases <- predicted_cases
write.csv(new_data2, "D:/zha/DLNM/GAM/predicted_cases_dianon.csv", row.names = FALSE)



#----tm vs rra----AIC会很大，作废
#手足口gam
#载入腹泻数据
data_HFMD1 <- read.csv("D:\\zha\\DLNM\\GAM\\DageHFMD.csv", header = TRUE, sep = ",", quote = "\"")
#年龄变分类项
data_HFMD1$AgeGroup <- as.factor(data_HFMD1$age)
gam_model4 <- gam(cases ~ s(Tm, RRRa) + ti(Tm, RRRa, bs = "tp") + factor(AgeGroup),
                  data = data_HFMD1, family = poisson(), select = TRUE)
#模型摘要
#summary(gam_model4)
#创建新data
new_data01 <- expand.grid(Tm = seq(min(data_HFMD1$Tm), max(data_HFMD1$Tm), length.out = 100), 
                        RRRa = seq(min(data_HFMD1$RRRa), max(data_HFMD1$RRRa), length.out = 100), AgeGroup = levels(data_HFMD1$AgeGroup))
predicted_cases3 <- predict(gam_model4, newdata = new_data01, type = "response")
new_data01$PredictedCases3 <- predicted_cases3
write.csv(new_data01, "D:/zha/DLNM/GAM/predicted_cases_HFMD1.csv", row.names = FALSE)



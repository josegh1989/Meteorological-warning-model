pacman::p_load(dlnm,splines,psych,flexmix,ggplot2,ROCR,pscl,openxlsx)

##读取数据
data<-read.csv("D:\\zha\\DLNM\\SZ.csv")

#设置工作目录
setwd("D:\\zha\\DLNM")
#-----变量-----
#总
variables0 <- c("hfmd")
population_labels0 <- c("hfmd-All") 

variables1 <- c("DV")
population_labels1 <- c("DV-All") 

variables2 <- c("DN")
population_labels2 <- c("DN-All") 

#性别
variables00 <- c("H.male")
population_labels00 <- c("hfmd-Male") 

variables01 <- c("H.female")
population_labels01 <- c("hfmd-Female")

variables02 <- c("DV.male")
population_labels02 <- c("DV-Male")

variables03 <- c("DV.female")
population_labels03 <- c("DV-Female")

variables04 <- c("DN.male")
population_labels04 <- c("DN-Male")

variables05 <- c("DN.female")
population_labels05 <- c("DN-Female")

#年龄

variables000 <- c("H0y")
population_labels000 <- c("hfmd-0y") 

variables001 <- c("H1.5y")
population_labels001 <- c("hfmd-1-5y") 

variables002 <- c("H6.20y")
population_labels002 <- c("hfmd-6-20y") 

variables003 <- c("H.20y")
population_labels003 <- c("hfmd->20y") 

variables004 <- c("DV0y")
population_labels004 <- c("DV-0y")

variables005 <- c("DV1.5y")
population_labels005 <- c("DV-1-5y")

variables006 <- c("DV6.20y")
population_labels006 <- c("DV-6-20y")

variables007 <- c("DV.20y")
population_labels007 <- c("DV->20y")

variables008 <- c("DN0y")
population_labels008 <- c("DN-0y")

variables009 <- c("DN1.5y")
population_labels009 <- c("DN-1-5y")

variables010 <- c("DN6.20y")
population_labels010 <- c("DN-6-20y")

variables011 <- c("DN.20y")
population_labels011 <- c("DN->20y")

#----跑模型-----
#HFMDALL
var_name0 <- variables0

# 构建原始模型（暴露因素选择Tm/Pm2）
basis.tm0 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=5),
                        arglag=list(knots=logknots(21,3)))

model_raw0 <- glm(get(var_name0) ~ basis.tm0 + ns(time, 11 * 7) + 
                    ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals <- resid(model_raw0)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals0 <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])

model0 <- glm(get(var_name0) ~ basis.tm0 + ns(time, 11 * 7) + 
                ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals0,
              family = quasipoisson(), data = data)

pred.tm0 <- crosspred(basis.tm0, model0, by = 0.1, cumul = TRUE,
                      cen = median(data$Tm, na.rm = TRUE))

#DVAll
var_name1 <- variables1

basis.tm1 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=4),
                        arglag=list(knots=logknots(21,5)))

model_raw1 <- glm(get(var_name1) ~ basis.tm1 + ns(time, 11 * 7) + 
                    ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

residuals1 <- resid(model_raw1)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals1 <- c(rep(NA, lag_window), residuals1[1:(n - lag_window)])

model1 <- glm(get(var_name1) ~ basis.tm1 + ns(time, 11 * 7) + 
                ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals1,
              family = quasipoisson(), data = data)

pred.tm1 <- crosspred(basis.tm1, model1, by = 0.1, cumul = TRUE,
                      cen = median(data$Tm, na.rm = TRUE))

#DNALL
var_name2 <- variables2

basis.tm2 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=4),
                        arglag=list(knots=logknots(21,3)))

model_raw2 <- glm(get(var_name2) ~ basis.tm2 + ns(time, 11 * 7) + 
                    ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

residuals2 <- resid(model_raw2)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals2 <- c(rep(NA, lag_window), residuals2[1:(n - lag_window)])

model2 <- glm(get(var_name2) ~ basis.tm2 + ns(time, 11 * 7) + 
                ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals2,
              family = quasipoisson(), data = data)

pred.tm2 <- crosspred(basis.tm2, model2, by = 0.1, cumul = TRUE,
                      cen = median(data$Tm, na.rm = TRUE))


#hfmd-male

var_name00 <- variables00

basis.tm00 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,3)))

model_raw00 <- glm(get(var_name00) ~ basis.tm00 + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals00 <- resid(model_raw00)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals00 <- c(rep(NA, lag_window), residuals00[1:(n - lag_window)])

model00 <- glm(get(var_name00) ~ basis.tm00 + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals00,
               family = quasipoisson(), data = data)

pred.tm00 <- crosspred(basis.tm00, model00, by = 0.1, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))

#hfmd-female
var_name01 <- variables01

basis.tm01 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,3)))

model_raw01 <- glm(get(var_name01) ~ basis.tm01 + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals01 <- resid(model_raw01)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals01 <- c(rep(NA, lag_window), residuals01[1:(n - lag_window)])

model01 <- glm(get(var_name01) ~ basis.tm01 + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals01,
               family = quasipoisson(), data = data)

pred.tm01 <- crosspred(basis.tm01, model01, by = 0.1, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))

#DV-male
var_name02 <- variables02

basis.tm02 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(21,5)))

model_raw02 <- glm(get(var_name02) ~ basis.tm02 + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals02 <- resid(model_raw02)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals02 <- c(rep(NA, lag_window), residuals02[1:(n - lag_window)])

model02 <- glm(get(var_name02) ~ basis.tm02 + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals02,
               family = quasipoisson(), data = data)

pred.tm02 <- crosspred(basis.tm02, model02, by = 0.1, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))

#DV-female
var_name03 <- variables03

basis.tm03 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(21,5)))

model_raw03 <- glm(get(var_name03) ~ basis.tm03 + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals03 <- resid(model_raw03)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals03 <- c(rep(NA, lag_window), residuals03[1:(n - lag_window)])

model03 <- glm(get(var_name03) ~ basis.tm03 + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals03,
               family = quasipoisson(), data = data)

pred.tm03 <- crosspred(basis.tm03, model03, by = 0.1, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))

#DN-male
var_name04 <- variables04

basis.tm04 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(21,3)))

model_raw04 <- glm(get(var_name04) ~ basis.tm04 + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals04 <- resid(model_raw04)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals04 <- c(rep(NA, lag_window), residuals04[1:(n - lag_window)])

model04 <- glm(get(var_name04) ~ basis.tm04 + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals04,
               family = quasipoisson(), data = data)

pred.tm04 <- crosspred(basis.tm04, model04, by = 0.1, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))

#DN-female
var_name05 <- variables05

basis.tm05 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(21,3)))

model_raw05 <- glm(get(var_name05) ~ basis.tm05 + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals05 <- resid(model_raw05)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals05 <- c(rep(NA, lag_window), residuals05[1:(n - lag_window)])

model05 <- glm(get(var_name05) ~ basis.tm05 + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals05,
               family = quasipoisson(), data = data)

pred.tm05 <- crosspred(basis.tm05, model05, by = 0.1, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))

#hfmd-age0
var_name000 <- variables000

basis.tm000 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw000 <- glm(get(var_name000) ~ basis.tm000 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals000 <- resid(model_raw000)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals000 <- c(rep(NA, lag_window), residuals000[1:(n - lag_window)])

model000 <- glm(get(var_name000) ~ basis.tm000 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals000,
                family = quasipoisson(), data = data)

pred.tm000 <- crosspred(basis.tm000, model000, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#hfmd-age1-5
var_name001 <- variables001

basis.tm001 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw001 <- glm(get(var_name001) ~ basis.tm001 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals001 <- resid(model_raw001)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals001 <- c(rep(NA, lag_window), residuals001[1:(n - lag_window)])

model001 <- glm(get(var_name001) ~ basis.tm001 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals001,
                family = quasipoisson(), data = data)

pred.tm001 <- crosspred(basis.tm001, model001, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#hfmd-age6-20
var_name002 <- variables002

basis.tm002 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw002 <- glm(get(var_name002) ~ basis.tm002 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals002 <- resid(model_raw002)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals002 <- c(rep(NA, lag_window), residuals002[1:(n - lag_window)])

model002 <- glm(get(var_name002) ~ basis.tm002 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals002,
                family = quasipoisson(), data = data)

pred.tm002 <- crosspred(basis.tm002, model002, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#hfmd-age>20
var_name003 <- variables003

basis.tm003 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw003 <- glm(get(var_name003) ~ basis.tm003 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals003 <- resid(model_raw003)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals003 <- c(rep(NA, lag_window), residuals003[1:(n - lag_window)])

model003 <- glm(get(var_name003) ~ basis.tm003 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals003,
                family = quasipoisson(), data = data)

pred.tm003 <- crosspred(basis.tm003, model003, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DV-age0
var_name004 <- variables004

basis.tm004 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,5)))

model_raw004 <- glm(get(var_name004) ~ basis.tm004 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals004 <- resid(model_raw004)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals004 <- c(rep(NA, lag_window), residuals004[1:(n - lag_window)])

model004 <- glm(get(var_name004) ~ basis.tm004 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals004,
                family = quasipoisson(), data = data)

pred.tm004 <- crosspred(basis.tm004, model004, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DV-age1-5
var_name005 <- variables005

basis.tm005 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,5)))

model_raw005 <- glm(get(var_name005) ~ basis.tm005 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals005 <- resid(model_raw005)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals005 <- c(rep(NA, lag_window), residuals005[1:(n - lag_window)])

model005 <- glm(get(var_name005) ~ basis.tm005 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals005,
                family = quasipoisson(), data = data)

pred.tm005 <- crosspred(basis.tm005, model005, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DV-age6-20
var_name006 <- variables006

basis.tm006 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,5)))

model_raw006 <- glm(get(var_name006) ~ basis.tm006 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals006 <- resid(model_raw006)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals006 <- c(rep(NA, lag_window), residuals006[1:(n - lag_window)])

model006 <- glm(get(var_name006) ~ basis.tm006 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals006,
                family = quasipoisson(), data = data)

pred.tm006 <- crosspred(basis.tm006, model006, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DV-age>20
var_name007 <- variables007

basis.tm007 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,5)))

model_raw007 <- glm(get(var_name007) ~ basis.tm007 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals007 <- resid(model_raw007)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals007 <- c(rep(NA, lag_window), residuals007[1:(n - lag_window)])

model007 <- glm(get(var_name007) ~ basis.tm007 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals007,
                family = quasipoisson(), data = data)

pred.tm007 <- crosspred(basis.tm007, model007, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DN-age0
var_name008 <- variables008

basis.tm008 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,3)))

model_raw008 <- glm(get(var_name008) ~ basis.tm008 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals008 <- resid(model_raw008)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals008 <- c(rep(NA, lag_window), residuals008[1:(n - lag_window)])

model008 <- glm(get(var_name008) ~ basis.tm008 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals008,
                family = quasipoisson(), data = data)

pred.tm008 <- crosspred(basis.tm008, model008, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DN-age1-5
var_name009 <- variables009

basis.tm009 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,3)))

model_raw009 <- glm(get(var_name009) ~ basis.tm009 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals009 <- resid(model_raw009)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals009 <- c(rep(NA, lag_window), residuals009[1:(n - lag_window)])

model009 <- glm(get(var_name009) ~ basis.tm009 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals009,
                family = quasipoisson(), data = data)

pred.tm009 <- crosspred(basis.tm009, model009, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DN-age6-20
var_name010 <- variables010

basis.tm010 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,3)))

model_raw010 <- glm(get(var_name010) ~ basis.tm010 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals010 <- resid(model_raw010)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals010 <- c(rep(NA, lag_window), residuals010[1:(n - lag_window)])

model010 <- glm(get(var_name010) ~ basis.tm010 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals010,
                family = quasipoisson(), data = data)

pred.tm010 <- crosspred(basis.tm010, model010, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#DN-age>20
var_name011 <- variables011

basis.tm011 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=4),
                          arglag=list(knots=logknots(21,3)))

model_raw011 <- glm(get(var_name011) ~ basis.tm011 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals011 <- resid(model_raw011)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals011 <- c(rep(NA, lag_window), residuals011[1:(n - lag_window)])

model011 <- glm(get(var_name011) ~ basis.tm011 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals011,
                family = quasipoisson(), data = data)

pred.tm011 <- crosspred(basis.tm011, model011, by = 0.1, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#----画lag图-----

tiff(filename = "Tm-Lag.tiff", width = 10, height = 12, units = "in", res = 600)
#png(filename = "Tm-Lag.png", width = 10, height = 12, units = "in", res = 600)
# 设置图形布局参数

par(mfrow = c(4, 3))#4行12张图,宽：高=10:12 
#---Sex----
#---COLD EFFECT----
plot(pred.tm00, ptype="slices", ci="area", col="blue", lwd = 2, var = 13.8, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     main = "HFMD(Cold)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm01, ptype="slices", ci="area", lwd = 2, lty = 2, var = 13.8, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("Male", "Female"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)

plot(pred.tm02, ptype="slices", ci="area", col="blue", lwd = 2, var = 13.8, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     main = "DV(Cold)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm03, ptype="slices", ci="area", lwd = 2, lty = 2, var = 13.8, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("Male", "Female"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)

plot(pred.tm04, ptype="slices", ci="area", col="blue", lwd = 2, var = 13.8, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     main = "DN(Cold)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm05, ptype="slices", ci="area", lwd = 2, lty = 2, var = 13.8, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("Male", "Female"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)
#---HOT EFFECT----

plot(pred.tm00, ptype="slices", ci="area", col="blue", lwd = 2, var = 30.0, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     main = "HFMD(Hot)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm01, ptype="slices", ci="area", lwd = 2, lty = 2, var = 30.0, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("Male", "Female"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)

plot(pred.tm02, ptype="slices", ci="area", col="blue", lwd = 2, var = 30.0, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.9,1.16), main = "DV(Hot)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm03, ptype="slices", ci="area", lwd = 2, lty = 2, var = 30.0, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("Male", "Female"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)

plot(pred.tm04, ptype="slices", ci="area", col="blue", lwd = 2, var = 30.0, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.9,1.1), main = "DN(Hot)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm05, ptype="slices", ci="area", lwd = 2, lty = 2, var = 30.0, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("Male", "Female"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)

#---AGE----
#----COLD EFFECT----
#HFMD
plot(pred.tm000, ptype="slices", ci="area", col="#000079", lwd = 2, var = 13.8, ci.arg=list(col=rgb(0,0,1,0.35)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.7,1.25), main = "HFMD(Cold)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm001, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 2, col="#750075", ci.arg=list(col=rgb(0.6,0,0.7,0.25)))
lines(pred.tm002, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 5, col="#FF95CA", ci.arg=list(col=rgb(0.6,0.3,0.3,0.15)))
lines(pred.tm003, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 4, col="#00E3E3", ci.arg=list(col=rgb(0,0.3,0.5,0.05)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("0", "1-5", "6-20", ">20"), col=c("#000079", "#750075", "#FF95CA", "#00E3E3"), lty=c(1, 2, 5, 4), bty = "n",
       inset=0.01, cex=0.8, y.intersp=0.85)

#DV
plot(pred.tm004, ptype="slices", ci="area", col="#000079", var = 13.8, lwd = 2, ci.arg=list(col=rgb(0,0,1,0.35)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.6,1.25), main = "DV(Cold)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm005, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 2, col="#750075", ci.arg=list(col=rgb(0.6,0,0.7,0.25)))
lines(pred.tm006, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 5, col="#FF95CA", ci.arg=list(col=rgb(0.6,0.3,0.3,0.05)))
lines(pred.tm007, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 4, col="#00E3E3", ci.arg=list(col=rgb(0,0.3,0.5,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("0", "1-5", "6-20", ">20"), col=c("#000079", "#750075", "#FF95CA", "#00E3E3"), lty=c(1, 2, 5, 4), bty = "n",
       inset=0, cex=0.8, y.intersp=0.85)
#DN
plot(pred.tm008, ptype="slices", ci="area", col="#000079", var = 13.8, lwd = 1, ci.arg=list(col=rgb(0,0,1,0.35)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.78,1.07), main = "DN(Cold)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm009, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 2, col="#750075", ci.arg=list(col=rgb(0.6,0,0.7,0.25)))
lines(pred.tm010, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 5, col="#FF95CA", ci.arg=list(col=rgb(0.6,0.3,0.3,0.05)))
lines(pred.tm011, ptype="slices", ci="area", var = 13.8, lwd = 2, lty = 4, col="#00E3E3", ci.arg=list(col=rgb(0,0.3,0.5,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("0", "1-5", "6-20", ">20"), col=c("#000079", "#750075", "#FF95CA", "#00E3E3"), lty=c(1, 2, 5, 4), bty = "n",
       inset=0, cex=0.8, y.intersp=0.85)

#----HOT EFFECT----
#HFMD
plot(pred.tm000, ptype="slices", ci="area", col="#000079", lwd = 2, var = 30.0, ci.arg=list(col=rgb(0,0,1,0.35)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.9,1.25), main = "HFMD(Hot)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm001, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 2, col="#750075", ci.arg=list(col=rgb(0.6,0,0.7,0.25)))
lines(pred.tm002, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 5, col="#FF95CA", ci.arg=list(col=rgb(0.6,0.3,0.3,0.15)))
lines(pred.tm003, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 4, col="#00E3E3", ci.arg=list(col=rgb(0,0.3,0.5,0.05)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("0", "1-5", "6-20", ">20"), col=c("#000079", "#750075", "#FF95CA", "#00E3E3"), lty=c(1, 2, 5, 4), bty = "n",
       inset=0.01, cex=0.8, y.intersp=0.85)

#DV
plot(pred.tm004, ptype="slices", ci="area", col="#000079", var = 30.0, lwd = 2, ci.arg=list(col=rgb(0,0,1,0.35)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.7,1.2), main = "DV(Hot)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm005, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 2, col="#750075", ci.arg=list(col=rgb(0.6,0,0.7,0.25)))
lines(pred.tm006, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 5, col="#FF95CA", ci.arg=list(col=rgb(0.6,0.3,0.3,0.05)))
lines(pred.tm007, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 4, col="#00E3E3", ci.arg=list(col=rgb(0,0.3,0.5,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("0", "1-5", "6-20", ">20"), col=c("#000079", "#750075", "#FF95CA", "#00E3E3"), lty=c(1, 2, 5, 4), bty = "n",
       inset=0, cex=0.8, y.intersp=0.85)
#DN
plot(pred.tm008, ptype="slices", ci="area", col="#000079", var = 30.0, lwd = 1, ci.arg=list(col=rgb(0,0,1,0.35)), xlab = "Lag(days)", ylab = "RR(95%CI)", 
     ylim=c(0.85,1.07), main = "DN(Hot)"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm009, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 2, col="#750075", ci.arg=list(col=rgb(0.6,0,0.7,0.25)))
lines(pred.tm010, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 5, col="#FF95CA", ci.arg=list(col=rgb(0.6,0.3,0.3,0.05)))
lines(pred.tm011, ptype="slices", ci="area", var = 30.0, lwd = 2, lty = 4, col="#00E3E3", ci.arg=list(col=rgb(0,0.3,0.5,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("bottomright", legend=c("0", "1-5", "6-20", ">20"), col=c("#000079", "#750075", "#FF95CA", "#00E3E3"), lty=c(1, 2, 5, 4), bty = "n",
       inset=0, cex=0.8, y.intersp=0.85)

par(mfrow = c(1, 1))
dev.off()  







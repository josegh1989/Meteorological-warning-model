pacman::p_load(dlnm,splines,psych,flexmix,ggplot2,ROCR,pscl,openxlsx)

data<-read.csv("D:\\zha\\DLNM\\SZ.csv")
setwd("D:\\zha\\DLNM")
variables <- c("hfmd")
population_labels <- c("hfmd-All") 

variables <- c("DV")
population_labels <- c("DV-All") 

variables <- c("DN")
population_labels <- c("DN-All") 

var_name <- variables


basis.tm <- crossbasis(data$Tm, lag=21,           
                       argvar=list(fun="ns",df=5),
                       arglag=list(knots=logknots(21,3)))

model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                   ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                   as.factor(dow) + as.factor(holiday2),
                 family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals <- resid(model_raw)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])

model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
               ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
               as.factor(dow) + as.factor(holiday2) + lag_residuals,
             family = quasipoisson(), data = data)


tiff(filename = "figuredn.tiff", width = 10, height = 5, units = "in", res = 300)
# 设置图形布局参数
par(mfrow = c(1, 2))  #1行2张图

##5.敏感性分析
#5.1最大滞后时间
ii_values <- c(14, 21, 28)  # 存储所有要绘制的ii值
colors <- c(1,2,3)  # 为每条曲线指定颜色

#1.绘制第一条曲线lag=14
basis.tm <- crossbasis(data$Tm, lag=ii_values[1],
                       argvar=list(fun="ns",df=5),
                       arglag=list(knots=logknots(ii_values[1],3)))
pred.tm <- crosspred(basis.tm, model, by = 0.05,
                     cen = median(data$Tm, na.rm = TRUE))
plot(pred.tm, "overall", col = colors[1], cex.axis = 1.50,
     ci="n",ylim=c(0.5,5),
     xlab = "Tm(℃)", ylab = "RR",
     main = "", cex.main = 1.5)

#2.循环绘制剩余的曲线
for (i in 2:length(ii_values)) {
  basis.tm <- crossbasis(data$Tm, lag=ii_values[i],
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(ii_values[i],3)))
  
  pred.tm <- crosspred(basis.tm, model, by = 0.1,
                       cen = median(data$Tm, na.rm = TRUE))
  
  # 使用lines函数在同一图形中添加曲线
  lines(pred.tm, "overall", col = colors[i], lwd = 2)
}

#3.添加图例
legend("topleft", legend = paste("lag =", ii_values), col = colors, lwd = 2,
       cex = 0.8)  # 调整图例大小

#5.2控制自相关
# 定义颜色
color_raw <- "black"    # 未控制自相关的线段颜色
color_controlled <- "blue"  # 已控制自相关的线段颜色

# 创建分布滞后基础
basis.tm <- crossbasis(data$Tm, lag=21,
                       argvar=list(fun="ns",df=5),
                       arglag=list(knots=logknots(21,3)))

# 使用原始模型进行预测
pred.tm_raw <- crosspred(basis.tm, model_raw, by = 0.1,
                         cen = median(data$Tm, na.rm = TRUE))

# 绘制未控制自相关的预测结果图
plot(pred.tm_raw, "overall", col = color_raw, cex.axis = 1.50,
     ci="n",  # 不绘制置信区间
     xlab = "Tm(℃)", ylab = "RR" ,    main = "", cex.main = 1.5)

# 使用控制自相关模型进行预测
pred.tm <- crosspred(basis.tm, model, by = 0.1,
                     cen = median(data$Tm, na.rm = TRUE))

# 在同一图形中添加已控制自相关的预测结果图
lines(pred.tm, "overall", col = color_controlled, lwd = 2, lty = 2, ci="n")

# 添加图例
legend("topleft", legend = c("Uncontrolled autocorrelation", "Control autocorrelation"),
       col = c(color_raw, color_controlled), lwd = 2, lty = 1)


dev.off()

#----DV----
variables <- c("DV")
population_labels <- c("DV-All") 

var_name <- variables

basis.tm <- crossbasis(data$Tm, lag=21,           
                       argvar=list(fun="ns",df=4),
                       arglag=list(knots=logknots(21,5)))

model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                   ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                   as.factor(dow) + as.factor(holiday2),
                 family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals <- resid(model_raw)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])

model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
               ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
               as.factor(dow) + as.factor(holiday2) + lag_residuals,
             family = quasipoisson(), data = data)


tiff(filename = "figuredv.tiff", width = 10, height = 5, units = "in", res = 300)
# 设置图形布局参数
par(mfrow = c(1, 2))  #1行2张图

##5.敏感性分析
#5.1最大滞后时间
ii_values <- c(14, 21, 28)  # 存储所有要绘制的ii值
colors <- c(1,2,3)  # 为每条曲线指定颜色

#1.绘制第一条曲线lag=14
basis.tm <- crossbasis(data$Tm, lag=ii_values[1],
                       argvar=list(fun="ns",df=4),
                       arglag=list(knots=logknots(ii_values[1],5)))
pred.tm <- crosspred(basis.tm, model, by = 0.05,
                     cen = median(data$Tm, na.rm = TRUE))
plot(pred.tm, "overall", col = colors[1], cex.axis = 1.50,
     ci="n",ylim=c(0.5,5),
     xlab = "Tm(℃)", ylab = "RR",
     main = "", cex.main = 1.5)

#2.循环绘制剩余的曲线
for (i in 2:length(ii_values)) {
  basis.tm <- crossbasis(data$Tm, lag=ii_values[i],
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(ii_values[i],5)))
  
  pred.tm <- crosspred(basis.tm, model, by = 0.1,
                       cen = median(data$Tm, na.rm = TRUE))
  
  # 使用lines函数在同一图形中添加曲线
  lines(pred.tm, "overall", col = colors[i], lwd = 2)
}

#3.添加图例
legend("topleft", legend = paste("lag =", ii_values), col = colors, lwd = 2,
       cex = 0.8)  # 调整图例大小

#5.2控制自相关
# 定义颜色
color_raw <- "black"    # 未控制自相关的线段颜色
color_controlled <- "blue"  # 已控制自相关的线段颜色

# 创建分布滞后基础
basis.tm <- crossbasis(data$Tm, lag=21,
                       argvar=list(fun="ns",df=4),
                       arglag=list(knots=logknots(21,5)))

# 使用原始模型进行预测
pred.tm_raw <- crosspred(basis.tm, model_raw, by = 0.1,
                         cen = median(data$Tm, na.rm = TRUE))

# 绘制未控制自相关的预测结果图
plot(pred.tm_raw, "overall", col = color_raw, cex.axis = 1.50,
     ci="n",  # 不绘制置信区间
     xlab = "Tm(℃)", ylab = "RR" ,    main = "", cex.main = 1.5)

# 使用控制自相关模型进行预测
pred.tm <- crosspred(basis.tm, model, by = 0.1,
                     cen = median(data$Tm, na.rm = TRUE))

# 在同一图形中添加已控制自相关的预测结果图
lines(pred.tm, "overall", col = color_controlled, lwd = 2, lty = 2, ci="n")

# 添加图例
legend("topleft", legend = c("Uncontrolled autocorrelation", "Control autocorrelation"),
       col = c(color_raw, color_controlled), lwd = 2, lty = 1)


dev.off()

#----DN----
variables <- c("DN")
population_labels <- c("DN-All") 

var_name <- variables

basis.tm <- crossbasis(data$Tm, lag=21,           
                       argvar=list(fun="ns",df=4),
                       arglag=list(knots=logknots(21,3)))

model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                   ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                   as.factor(dow) + as.factor(holiday2),
                 family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals <- resid(model_raw)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])

model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
               ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
               as.factor(dow) + as.factor(holiday2) + lag_residuals,
             family = quasipoisson(), data = data)


tiff(filename = "figuredn.tiff", width = 10, height = 5, units = "in", res = 300)
# 设置图形布局参数
par(mfrow = c(1, 2))  #1行2张图

##5.敏感性分析
#5.1最大滞后时间
ii_values <- c(14, 21, 28)  # 存储所有要绘制的ii值
colors <- c(1,2,3)  # 为每条曲线指定颜色

#1.绘制第一条曲线lag=14
basis.tm <- crossbasis(data$Tm, lag=ii_values[1],
                       argvar=list(fun="ns",df=4),
                       arglag=list(knots=logknots(ii_values[1],3)))
pred.tm <- crosspred(basis.tm, model, by = 0.05,
                     cen = median(data$Tm, na.rm = TRUE))
plot(pred.tm, "overall", col = colors[1], cex.axis = 1.50,
     ci="n",ylim=c(0.5,5),
     xlab = "Tm(℃)", ylab = "RR",
     main = "", cex.main = 1.5)

#2.循环绘制剩余的曲线
for (i in 2:length(ii_values)) {
  basis.tm <- crossbasis(data$Tm, lag=ii_values[i],
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(ii_values[i],3)))
  
  pred.tm <- crosspred(basis.tm, model, by = 0.1,
                       cen = median(data$Tm, na.rm = TRUE))
  
  # 使用lines函数在同一图形中添加曲线
  lines(pred.tm, "overall", col = colors[i], lwd = 2)
}

#3.添加图例
legend("topleft", legend = paste("lag =", ii_values), col = colors, lwd = 2,
       cex = 0.8)  # 调整图例大小

#5.2控制自相关
# 定义颜色
color_raw <- "black"    # 未控制自相关的线段颜色
color_controlled <- "blue"  # 已控制自相关的线段颜色

# 创建分布滞后基础
basis.tm <- crossbasis(data$Tm, lag=21,
                       argvar=list(fun="ns",df=4),
                       arglag=list(knots=logknots(21,3)))

# 使用原始模型进行预测
pred.tm_raw <- crosspred(basis.tm, model_raw, by = 0.1,
                         cen = median(data$Tm, na.rm = TRUE))

# 绘制未控制自相关的预测结果图
plot(pred.tm_raw, "overall", col = color_raw, cex.axis = 1.50,
     ci="n",  # 不绘制置信区间
     xlab = "Tm(℃)", ylab = "RR" ,    main = "", cex.main = 1.5)

# 使用控制自相关模型进行预测
pred.tm <- crosspred(basis.tm, model, by = 0.1,
                     cen = median(data$Tm, na.rm = TRUE))

# 在同一图形中添加已控制自相关的预测结果图
lines(pred.tm, "overall", col = color_controlled, lwd = 2, lty = 2, ci="n")

# 添加图例
legend("topleft", legend = c("Uncontrolled autocorrelation", "Control autocorrelation"),
       col = c(color_raw, color_controlled), lwd = 2, lty = 1)


dev.off()


##模型评价
#1：QAIC/QBIC[G,2010] 以QAIC为主
phi <- summary(model_raw)$dispersion
logll <- sum(dpois(ceiling(model_raw$y), lambda=exp(predict(model_raw)), log=TRUE))
QAIC<--2*logll + 2*summary(model_raw)$df[3]*phi
QAIC
QBIC<--2*logll + log(length(resid(model_raw)))*summary(model_raw)$df[3]*phi
QBIC

#------------------------------3.2修正模型--------------------------------------
##1.绘制残差图（无自回归项的模型）
#提取的残差向量
residuals <- resid(model_raw)
length(residuals)#n-lag=5113-21=5092

# 绘制残差的时间序列图
ggplot(data.frame(Time = 1:length(residuals), Residuals = residuals), aes(x = Time, y = Residuals)) +
  geom_line() +
  ggtitle("Residuals vs Time") +
  xlab("Time") +
  ylab("Residuals")
# 绘制残差的自相关函数（ACF）图
acf(residuals, main = "Autocorrelation Function of Residuals")
# 绘制残差的偏自相关函数（PACF）图
pacf(residuals, main = "Partial Autocorrelation Function of Residuals")


##2.构建残差滞后项
# 创建X阶滞后残差项，前21个值设为NA
# 这里假设滞后的时间窗口为21，如果需要不同的时间窗口，可以修改这个值
residuals <- resid(model_raw)
lag_window <- 22 #滞后期+1
n <- nrow(data)
data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n-lag_window)])


##3.重新建模
model <- glm(hfmd~basis.tm + ns(time,11*7) 
             + ns(RRRa,3) +ns(Um,3)+ns(FFm,3) #+ns(Pm,3) 
             + as.factor(dow) + as.factor(holiday2)
             + lag_residuals,
             family=quasipoisson(),data)#quasipoisson类泊松分布


phi <- summary(model)$dispersion
logll <- sum(dpois(ceiling(model$y), lambda=exp(predict(model)), log=TRUE))
QAIC<--2*logll + 2*summary(model)$df[3]*phi
QAIC
QBIC<--2*logll + log(length(resid(model)))*summary(model)$df[3]*phi
QBIC 

##4.重新绘制残差图
residuals <- resid(model)
length(residuals)#n-lag-阶数=5113-21-1=5091
# 绘制残差的自相关函数（ACF）图
acf(residuals, main = "Autocorrelation Function of Residuals")
# 绘制残差的偏自相关函数（PACF）图
pacf(residuals, main = "Partial Autocorrelation Function of Residuals")

##0.等高线图
plot(pred.tm,"contour",cex.axis=1.20,
     xlab="日平均气温（℃）",ylab="滞后时间（d）",
     main="",cex.main=1.5,cex.lab=1.2)

##1.3D图：温度与发病(默认蓝色)
plot(pred.tm, #col = "#00FF00",
     xlab = "
     日平均气温（℃）",#enter键竟然能增加坐标轴标题和轴之间的距离！
     ylab = "
     滞后时间（d）", 
     zlab = "
     相对危险度",
)  

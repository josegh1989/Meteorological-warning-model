##加载包：dlnm分布滞后非线性模型包、调用splines包中的样条函数
pacman::p_load(dlnm,splines,psych,flexmix,ggplot2,ROCR,pscl,openxlsx)
#--------------------------------数据准备---------------------------------------
##读取数据
data<-read.csv("D:\\zha\\DLNM\\SZ.csv")
##选取数据：
#data <- data[data$Year >= 2010 & data$Year <= 2019,] 
dim(data)
dput(names(data))
#设置工作目录
setwd("D:\\zha\\DLNM")

#换算： 1mmHg = 1.3332 hPa
data$Pm2=data$Pm*1.3332

#学习关键绘图函数
?lines.crosspred
#------------------------------A.批量输出主要图形-------------------------------------
#设置图形分辨率
png(filename = "HFMD-Tm-OVERALL.png", width = 8, height = 9, units = "in", res = 300)
# 设置图形布局参数
#par(mfrow = c(1, 1))  #默认1行1张图,宽：高=6:5
#par(mfrow = c(1, 7))#1行7张图,宽：高=18:3
#par(mfrow = c(2, 3))#2行6张图,宽：高=6:5
par(mfrow = c(3, 3))#3行7张图,宽：高=8:9

variables <- c("hfmd", "H.male", "H.female","H0y", "H1.5y", "H6.20y", "H.20y"
               )
#population_labels <- c("全人群", "男性", "女性","0岁","1-5岁","6-20岁",">20岁") 
population_labels <- c("All", "Male", "Female", "0y","1-5y","6-20y",">20y") 
#population_labels <- c("Hot effect (All)", "Hot effect (Male)", "Hot effect (Female)", 
#"Hot effect (0y)","Hot effect (1-5y)","Hot effect (6-20y)","Hot effect (>20y)") 
# population_labels <- c("低温（全人群）", "低温（男性）", "低温（女性）","低温（0岁）", "低温（1-5岁）", "低温（6-20岁）","低温（>20岁）") 
# population_labels <- c("高温（全人群）", "高温（男性）", "高温（女性）", "高温（0岁）", "高温（1-5岁）", "高温（6-20岁）","高温（>20岁）") 

for (i in 1:length(variables)) {
  var_name <- variables[i]
  
  # 构建原始模型（暴露因素选择Tm/Pm2）
  basis.tm <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,3)))
  
  model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)
  
  # 构建包含滞后残差的新模型
  residuals <- resid(model_raw)
  lag_window <- 22  # 滞后期+1
  n <- nrow(data)  # 确保数据集的行数是数值类型
  data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])
  
  model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals,
               family = quasipoisson(), data = data)
  
  pred.tm <- crosspred(basis.tm, model, by = 0.5, cumul = TRUE,
                       cen = median(data$Tm, na.rm = TRUE))
  
  # 1.绘制overall图形
  # plot(pred.tm, "overall", col = 2,ylim=c(0,4.5),
  #      #cex.axis = 1.50, cex.lab = 1.25, cex.main = 1.25,  # 坐标轴标签、坐标轴标题、标题字号设置
  #      xlab = "日平均气温（℃）", ylab = "相对危险度",
  #      main = population_labels[i])  # 设置对应的人群标题
  
  plot(pred.tm, "overall", col = 2,ylim=c(0,4.5),
       #cex.axis = 1.50, cex.lab = 1.25, cex.main = 1.25, 
       xlab = "Temperature(℃)", ylab = "RR(95%CI)", # xlab = Temperature/"Pressure(hpa)"
       main = population_labels[i])  
  
  #2.1 单日滞后-发病(P5/P95温度/气压)
  # plot(pred.tm, "slices", var=1023, col=2, lwd=1.5,ylim=c(0.85,1.2),
  #      ci="bars", type="p", pch=19, xlab="滞后时间（d）", ylab="相对危险度",
  #      main = population_labels[i])
  
  # plot(pred.tm, "slices", var=30.0, col=2, lwd=1.5,ylim=c(0.95,1.1),
  #      ci="bars", type="p", pch=19, xlab="滞后时间（d）", ylab="相对危险度", 
  #      main = population_labels[i])
  
  
  #2.2 累积滞后-发病(P5/P95温度)（2行6张图，长宽比=6:5）
  # plot(pred.tm, "slices", var=13.8, col=2, lwd=1.5,ylim=c(0.35,1.15),cumul=TRUE,
  #      ci="bars", type="p", pch=19, xlab="滞后时间（d）", ylab="累积相对危险度",
  #      main = population_labels[i])

  # plot(pred.tm, "slices", var=30.0, col=2, lwd=1.5,ylim=c(0.85,3.65),cumul=TRUE,
  #      ci="bars", type="p", pch=19, xlab="滞后时间（d）", ylab="累积相对危险度",
  #      main = population_labels[i])

  
  # ## 3.气温-发病(滞后：7/14/21天)
  # plot(pred.tm, "slices", lag=7, ci="n", col=1, lwd=1.5,ylim=c(0.85,1.1),
  #      xlab="日均温度（℃）", ylab="相对危险度",main = population_labels[i])
  # for(i in 1:3) lines(pred.tm, "slices", lag=c(10,14,21)[i], col=i+1, lwd=1.5)
  # legend("topleft", inset = 0.1,# 使用inset调整图例位置
  #        paste("Lag =",c(7,10,14,21)),
  #        col=1:4, lwd=1.5, cex=0.8,box.lty=0) # cex调整图例大小
  
  # ##4.3D图：温度与发病(默认蓝色) Daily Mean Temperature(°C)/ Pressure(hpa)
  # plot(pred.tm, col = "#30A9DE",theta=400, phi=20,  
  #      xlab = "
  #    Pressure(hpa)",#enter键竟然能增加坐标轴标题和轴之间的距离！
  #      ylab = "
  #    Lag(day)", 
  #      zlab = "
  #    RR",
  # ) 
  
}

dev.off()

#------------------------------B.批量导出数据-------------------------------------

#library(openxlsx)

variables <- c("hfmd", "H.male", "H.Female", 
               "H0y", "H1.5y", "H6.20y", "H.20y")

# 创建一个新的Excel工作簿
wb <- createWorkbook()

for (i in 1:length(variables)) {
  var_name <- variables[i]
  
  # 构建原始模型
  basis.tm <- crossbasis(data$Pm2, lag=21,
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,3)))
  
  model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)
  
  # 构建包含滞后残差的新模型
  residuals <- resid(model_raw)
  lag_window <- 22  # 滞后期+1
  n <- nrow(data)  # 确保数据集的行数是数值类型
  data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])
  
  model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals,
               family = quasipoisson(), data = data)
  
  pred.tm <- crosspred(basis.tm, model, by = 0.5, cumul = TRUE,
                       cen = median(data$Pm2, na.rm = TRUE))
  
  #暴露-效应（所有滞后日的累积效应）
  RR1 <- round(cbind(pred.tm$allRRfit,pred.tm$allRRlow,pred.tm$allRRhigh),digits=3)
  #暴露-滞后-效应（某一天的当日滞后效应）
  RR2 <- round(cbind(pred.tm$matRRfit,pred.tm$matRRlow,pred.tm$matRRhigh),digits=3)
  #暴露-滞后-效应（某一天的累积滞后效应）
  RR3 <- round(cbind(pred.tm$cumRRfit,pred.tm$cumRRlow,pred.tm$cumRRhigh),digits=3)
  # 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
  rr_ci <- data.frame(pred.tm$predvar,RR1,RR2,RR3)
  
  # 将结果添加到工作簿的工作表中
  addWorksheet(wb, paste0("", var_name))
  writeData(wb, sheet = paste0("", var_name), rr_ci)
  
}

# 保存工作簿到CSV文件
saveWorkbook(wb, "hfmd-SZ-Pm.xlsx", overwrite = TRUE)


#-------------------------C.单日滞后效应（改变因变量）----------------------------
#------------------------------①按性别分组
# 打开图形设备
png(filename = "HFMD-High pressure-Gender-T.png", width = 6, height = 5, units = "in", res = 300)
# 设置图形布局参数
par(mfrow = c(1, 1))  #默认1行1张图

variables <- c("H.male", "H.Female")
population_labels <- c("Male", "Female") 

##先绘制一个空的图形，后在循环中用 lines 函数添加每个模型的预测结果
# plot(NULL, xlim=c(0, 21), ylim=c(0.85, 1.2), 
#      xlab="Lag(day)", ylab="RR(95%CI)", main="Cold effect")#P5=13.8℃
# plot(NULL, xlim=c(0, 21), ylim=c(0.95, 1.1), 
#      xlab="Lag(day)", ylab="RR(95%CI)", main="Hot effect")#P95=30.0℃
plot(NULL, xlim=c(0, 21), ylim=c(0.80, 1.1), 
     xlab="Lag(day)", ylab="RR(95%CI)", main="Hyperbaric effect")#P95=1023.21→1023
# plot(NULL, xlim=c(0, 21), ylim=c(0.95, 1.05), 
#      xlab="Lag(day)", ylab="RR(95%CI)", main="Hypobaric effect")#P5=1002.47→1002.5

abline(h=1, col="black", lty=1, lwd=1) #添加RR=1的参照线

# 定义平移量
shifts <- c(0, 0.1, 0.2, 0.3)

for (i in 1:length(variables)) {
  var_name <- variables[i]
  
  # 构建原始模型
  basis.tm <- crossbasis(data$Pm2, lag=21,
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,3)))
  
  model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)
  
  # 构建包含滞后残差的新模型
  residuals <- resid(model_raw)
  lag_window <- 22  # 滞后期+1
  n <- nrow(data)  # 确保数据集的行数是数值类型
  data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])
  
  model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals,
               family = quasipoisson(), data = data)
  
  pred.tm <- crosspred(basis.tm, model, by = 0.5,  cumul = TRUE,
                       cen = median(data$Pm2, na.rm = TRUE))
  
  # 应用平移
  pred.tm$lag <- pred.tm$lag + shifts[i]
  # lines(pred.tm, "slices", ci="bars", type="p", pch=19,ci.arg=list(col=i),
  #        ci.level=0.95, var=13.8, col=i, lwd=1.5) #var=13.8 /30.0
  lines(pred.tm, "slices", ci="bars", type="p", pch=19,ci.arg=list(col=i),
        ci.level=0.95, var=1023, col=i, lwd=1.5) #var=1002.5 /1023
}

# 添加图例
legend("topright", legend=population_labels, col=1:length(variables),
       lty=1:1, pch=19, bty="n")
# 关闭图形设备
dev.off()


#-----------------------------------②按年龄分组
# 打开图形设备
png(filename = "HFMD-Low pressure-Age.png", width = 6, height = 5, units = "in", res = 300)
# 设置图形布局参数
par(mfrow = c(1, 1))  #默认1行1张图

variables <- c("H0y", "H1.5y", "H6.20y", "H.20y")
population_labels <- c("<1Y", "1~5Y", "6~20Y", ">20Y")

# 定义平移量
shifts <- c(0, 0.1, 0.2, 0.3)

# # 定义颜色向量，每个模型使用不同的颜色
colors <- c("#30A9DE", "#EFDC05","#E53A40", "#090707")  

# 先绘制一个空的图形，后在循环中用 lines 函数添加每个模型的预测结果
# plot(NULL, xlim=c(0, 21), ylim=c(0.85, 1.2), 
#      xlab="Lag(day)", ylab="RR(95%CI)", main="Cold effect")
# plot(NULL, xlim=c(0, 21), ylim=c(0.95, 1.1), 
#      xlab="Lag(day)", ylab="RR(95%CI)", main="Hot effect")
# plot(NULL, xlim=c(0, 21), ylim=c(0.80, 1.1), 
#      xlab="Lag(day)", ylab="RR(95%CI)", main="Hyperbaric effect")#P95=1023.21→1023
plot(NULL, xlim=c(0, 21), ylim=c(0.80, 1.1),
     xlab="Lag(day)", ylab="RR(95%CI)", main="Hypobaric effect")#P5=1002.47→1002.5

# 添加RR=1的参照线
abline(h=1, col="black", lty=1, lwd=1)

for (i in 1:length(variables)) {
  var_name <- variables[i]
  
  # 构建原始模型
  basis.tm <- crossbasis(data$Pm2, lag=21,
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,3)))
  
  model_raw <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)
  
  # 构建包含滞后残差的新模型
  residuals <- resid(model_raw)
  lag_window <- 22  # 滞后期+1
  n <- nrow(data)  # 确保数据集的行数是数值类型
  data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])
  
  model <- glm(get(var_name) ~ basis.tm + ns(time, 11 * 7) + 
                 ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals,
               family = quasipoisson(), data = data)
  
  pred.tm <- crosspred(basis.tm, model, by = 0.5, cumul = TRUE, #by=0.5/0.05→Tm/Pm2
                       cen = median(data$Pm2, na.rm = TRUE))
  
  # 应用平移
  pred.tm$lag <- pred.tm$lag + shifts[i]
  # lines(pred.tm, "slices", ci="bars", type="p", pch=19, ci.arg=list(col=colors[i]),
  #       ci.level=0.95, var=13.8, col=colors[i], lwd=1.5) #var=13.8 /30.0
  lines(pred.tm, "slices", ci="bars", type="p", pch=19,ci.arg=list(col=colors[i]),
        ci.level=0.95, var = 1002.5, col=colors[i], lwd=1.5) #var=1002.5 /1023
}
# 添加图例
legend("bottomright", legend=population_labels, col=colors,#"bottomright"/"topright"
       lty=1:1, pch=19, bty="n")


# 关闭图形设备
dev.off()

#------------------------------D.组合敏感性分析图形-------------------------------
#设置图形分辨率
png(filename = "figure1.png", width = 8, height = 5, units = "in", res = 300)
# 设置图形布局参数
par(mfrow = c(1, 2))  #1行2张图

##5.敏感性分析
#5.1最大滞后时间
ii_values <- c(14, 21, 28)  # 存储所有要绘制的ii值
colors <- c(1,2,3)  # 为每条曲线指定颜色

#1.绘制第一条曲线lag=14
basis.tm <- crossbasis(data$Tm, lag=ii_values[1],
                       argvar=list(fun="ns",df=5),
                       arglag=list(knots=logknots(ii_values[1],3)))
pred.tm <- crosspred(basis.tm, model, by = 0.05,
                     cen = median(data$Tm, na.rm = TRUE))
plot(pred.tm, "overall", col = colors[1], cex.axis = 1.50,
     ci="n",ylim=c(0.5,5),
     xlab = "日均温度(℃)", ylab = "相对危险度",
     main = "", cex.main = 1.5)

#2.循环绘制剩余的曲线
for (i in 2:length(ii_values)) {
  basis.tm <- crossbasis(data$Tm, lag=ii_values[i],
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(ii_values[i],3)))
  
  pred.tm <- crosspred(basis.tm, model, by = 0.1,
                       cen = median(data$Tm, na.rm = TRUE))
  
  # 使用lines函数在同一图形中添加曲线
  lines(pred.tm, "overall", col = colors[i], lwd = 2)
}

#3.添加图例
legend("topleft", legend = paste("lag =", ii_values), col = colors, lwd = 2,
       cex = 0.8)  # 调整图例大小


#5.2控制自相关
# 定义颜色
color_raw <- "black"    # 未控制自相关的线段颜色
color_controlled <- "blue"  # 已控制自相关的线段颜色

# 创建分布滞后基础
basis.tm <- crossbasis(data$Tm, lag=21,
                       argvar=list(fun="ns",df=5),
                       arglag=list(knots=logknots(21,3)))

# 使用原始模型进行预测
pred.tm_raw <- crosspred(basis.tm, model_raw, by = 0.1,
                         cen = median(data$Tm, na.rm = TRUE))

# 绘制未控制自相关的预测结果图
plot(pred.tm_raw, "overall", col = color_raw, cex.axis = 1.50,
     ci="n",  # 不绘制置信区间
     xlab = "日均温度(℃)", ylab = "相对危险度",
     main = "", cex.main = 1.5)

# 使用控制自相关模型进行预测
pred.tm <- crosspred(basis.tm, model, by = 0.1,
                     cen = median(data$Tm, na.rm = TRUE))

# 在同一图形中添加已控制自相关的预测结果图
lines(pred.tm, "overall", col = color_controlled, lwd = 2, lty = 2, ci="n")

# 添加图例
legend("topleft", legend = c("未控制自相关", "已控制自相关"),
       col = c(color_raw, color_controlled), lwd = 2, lty = 1)


dev.off()

#------------------------------1.统计描述+初步分析------------------------------
####################################①统计描述
#换算： 1mmHg = 1.3332 hPa
data$Pm2=data$Pm*1.3332

# 指定要计算统计摘要的变量列表
variables <- c("hfmd", "diarrhea", "Tm","Pm2", "FFm", "Um", "RRRa")

# 初始化一个列表来存储统计摘要
stats_summary <- lapply(variables, function(var) {
  # 从数据框中提取变量，并计算统计摘要
  var_data <- data[[var]]
  stats <- c(
    Mean = round(mean(var_data, na.rm = TRUE), 2),
    SD = round(sd(var_data, na.rm = TRUE), 2),
    Min = round(min(var_data, na.rm = TRUE), 2),
    P5 = round(quantile(var_data, probs = 0.05, na.rm = TRUE), 2),
    P25 = round(quantile(var_data, probs = 0.25, na.rm = TRUE), 2),
    P50 = round(median(var_data, na.rm = TRUE), 2),
    P75 = round(quantile(var_data, probs = 0.75, na.rm = TRUE), 2),
    P95 = round(quantile(var_data, probs = 0.95, na.rm = TRUE), 2),
    Max = round(max(var_data, na.rm = TRUE), 2)
  )
  # 将统计摘要和变量名称组合为一个列表
  c(stats, Var = var)
})

# 将列表转换为数据框，确保变量名称作为列名
stats_df <- do.call(rbind, lapply(stats_summary, 
                                  function(x) setNames(x, c(names(x)[-length(x)], "Var"))))

# 将数据框写入Excel
write.csv(stats_df, "SZ-summary.csv")


########################################②相关分析
#批量相关：两两相关
all<-data[,12:46]
cor_result<-corr.test(all, method="spearman")

# 提取相关性矩阵
cor_matrix <- cor_result$r
# 提取P值
p_values <- cor_result$p
# 将相关性矩阵转换为数据框
cor_df <- as.data.frame(cor_matrix)
# 将P值添加到数据框中
cor_df$p_values <- p_values
# 将数据框写入Excel
write.csv(cor_df, "SZ-Correlation（2012-2022）.csv")

# 结果可视化
pairs(~diarrhea+RRRa+FFm+Um+Pm+Tm, data=data,
      main="Basic Scatter Plot Matrix")


#------------------------------1.5敏感性分析-------------------------------------
##1.QAIC/BAIC
#1.1 for循环[model_raw]
qaicbic <- function(model_raw) {
  phi <- summary(model_raw)$dispersion
  logll <- sum(dpois(ceiling(model_raw$y), lambda=exp(predict(model_raw)), log=TRUE))
  c(AIC=-2*logll + 2*summary(model_raw)$df[3]*phi,
    BIC=-2*logll + log(length(resid(model_raw)))*phi*summary(model_raw)$df[3])
}

tqba <- data.frame()
for (ii in 3:5) {
  for (jj in 3:5) {
    basis.tm <- crossbasis(data$Pm2, lag=21,
                           argvar=list(fun="ns",df=ii),
                           arglag=list(knots=logknots(21,jj)))
    model_raw <- glm(hfmd~basis.tm + ns(time,11*7) 
                     + ns(RRRa,3)+ns(FFm,3)+ns(Um,3)
                     + as.factor(holiday2)+ as.factor(dow),
                     family=quasipoisson(),data)
    
    residuals <- resid(model_raw)
    acf_result <- acf(residuals, plot = FALSE)  # 使用acf函数计算自相关系数和偏自相关系数
    pacf_values <- acf_result$acf[-1]  # pacf函数的输出中，偏自相关系数从第二个值开始
    sum_of_paac <- sum(abs(pacf_values))  # 计算偏自相关系数之和
    
    # 输出模型摘要，这里可以注释掉，因为它不会影响输出结果
    # summary(model_raw)
    
    # 将结果绑定到数据框中
    q <- data.frame(ii=ii, jj=jj, 
                    QAIC=qaicbic(model_raw)[1], QBIC=qaicbic(model_raw)[2], 
                    sum_of_paac=sum_of_paac)
    tqba <- rbind(tqba, q)
  }
}

# 打印tqba
print(tqba)
# 找出tqba中各个变量的最小值
min_values <- apply(tqba, 2, function(x) min(x, na.rm = TRUE))
print(min_values)



#1.2 for循环[model]
qaicbic <- function(model) {
  phi <- summary(model)$dispersion
  logll <- sum(dpois(ceiling(model$y), lambda=exp(predict(model)), log=TRUE))
  cbind((AIC=-2*logll + 2*summary(model)$df[3]*phi),
        (BIC=-2*logll + log(length(resid(model)))*phi*summary(model)$df[3]))}

tqba <- data.frame()
for (ii in 3:5) {
  for (jj in 3:5) {
    basis.tm<-crossbasis(data$Pm2, lag=21,
                         argvar=list(fun="ns",df=ii),
                         arglag=list(knots=logknots(21,jj)))
    
    model_raw <- glm(hfmd~basis.tm + ns(time,11*7) 
                     + ns(RRRa,3)+ns(FFm,3)+ns(Um,3)
                     + as.factor(holiday2)+ as.factor(dow),
                     family=quasipoisson(),data)
    
    residuals <- resid(model_raw)
    lag_window <- 22 #滞后期+1
    n <- nrow(data)
    data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n-lag_window)])
    
    model <- glm(hfmd~basis.tm + ns(time,14*7)
                 + ns(RRRa,3) +ns(Um,3)+ns(FFm,3) #+ns(Pm,3)
                 + as.factor(dow) +as.factor(holiday2)
                 + lag_residuals  ,
                 family=quasipoisson(),data)
    
    residuals <- resid(model)
    acf_result <- acf(residuals, plot = FALSE)  # 使用acf函数计算自相关系数和偏自相关系数
    pacf_values <- acf_result$acf[-1]  # pacf函数的输出中，偏自相关系数从第二个值开始
    sum_of_paac <- sum(abs(pacf_values))  # 计算偏自相关系数之和
    
    summary(model)
    q <- data.frame(ii=ii, jj=jj, 
                    QAIC=qaicbic(model)[1], QBIC=qaicbic(model)[2], 
                    sum_of_paac=sum_of_paac)
    tqba <- rbind(tqba, q)
  }
}

# 打印tqba
print(tqba)
# 找出tqba中各个变量的最小值
min_values <- apply(tqba, 2, function(x) min(x, na.rm = TRUE))
print(min_values)



##2.图形
# 初始化模型列表
model_list <- list()

# 2.1 for循环[model_raw]
for (ii in 3:5) {
  for (jj in 3:5) {
    basis.tm <- crossbasis(data$Tm, lag=21,
                           argvar=list(fun="ns",df=ii),
                           arglag=list(knots=logknots(21,jj)))
    
    model_raw <- glm(hfmd ~ basis.tm + ns(time, 11 * 7) + 
                       ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                       as.factor(dow) + as.factor(holiday2),
                     family = quasipoisson(), data = data)
    
    # 将模型存储到列表中
    model_list[[paste("model_", ii, jj, sep = "")]] <- model_raw
    
    pred.tm <- crosspred(basis.tm, model_raw, by = 0.1,
                         cen = median(data$Tm, na.rm = TRUE))
    
    # 绘制预测结果图
    plot(pred.tm, "overall", col = 2, cex.axis = 1.50,
         xlab = "温度(℃)", ylab = "RR",
         main = paste("hfmd - df =", ii, jj), cex.main = 1.5)
  }
}

# 2.2 for循环[model]
for (ii in 3:5) {
  for (jj in 3:5) {
  basis.tm <- crossbasis(data$Tm, lag=21,
                         argvar=list(fun="ns",df=ii),
                         arglag=list(knots=logknots(21,jj)))
  
  model_raw <- glm(hfmd ~ basis.tm + ns(time, 11 * 7) + 
                     ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)
  
  residuals <- resid(model_raw)
  lag_window <- 22 #滞后期+1
  n <- nrow(data)
  data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n-lag_window)])
  
  model <- glm(hfmd~basis.tm + ns(time,11*7)
               + ns(RRRa,3) +ns(Um,3)+ns(FFm,3) #+ns(Pm,3)
               + as.factor(dow) +as.factor(holiday2)
               + lag_residuals  ,
               family=quasipoisson(),data)
  
  # 将模型存储到列表中
  model_list[[paste("model_", ii, jj, sep = "")]] <- model
  
  pred.tm <- crosspred(basis.tm, model, by = 0.1,
                       cen = median(data$Tm, na.rm = TRUE))
  
  # 绘制预测结果图
  plot(pred.tm, "overall", col = 2, cex.axis = 1.50,
       xlab = "温度(℃)", ylab = "RR",
       main = paste("hfmd - df =", ii, jj), cex.main = 1.5)
    }
}
#------------------------------2.建立基函数-------------------------------------
##0.基函数的构建主要使用dlnm包中的crossbasis()函数
##1.暴露-反应维度拟合：采用自然立方样条函数
##2.暴露-滞后维度拟合：采用自然立方样条函数，滞后期选择21/14[刘天/阎思宇]，节点位置设置采用程序包提供的对数等间距的方法
##3.建立交叉基函数：拟合暴露-滞后-反应
#A.ns：自然三次样条函数（Natural cubic spline function）
#B.quantile()函数:是计算特定百分位数对应的值。
#C.na.rm=TRUE：表示剔除温度中的缺失值
#D.logknots(10,3)函数会基于对数尺度在0到10的范围内生成3个等间隔的结点。这些结点将用于构建滞后效应的平滑样条函数
#注意！！！降雨量10%百分位数仍为0，内部节点和边缘节点重合→crosspred会报错
#df=n+1=4：内部节点位置设置在第10、75与90百分位数(共3个节点)，边际节点固定为min、max（共2个节点） 
#argvar <- list(fun="ns",knots=quantile(data$Tm,c(25,50,75)/100,na.rm=TRUE)) 
#df=3+2：节点位置设置按默认的对数等间距(共3个节点)，边际节点固定为min、max（共2个节点）
#arglag <- list(knots=logknots(21,3))

basis.tm <- crossbasis(data$Tm, lag=21,
                       argvar=list(fun="ns",df=5),
                       arglag=list(knots=logknots(21,3)))
summary(basis.tm)
dim(basis.tm)
#------------------------------3.1初始模型---------------------------------------
##0.构建好交叉基之后需要结合回归模型进行效应估计，一般用广义线性模型glm()，然后使用family参数定义因变量分布及连接函数
##1.因变量为手足口发病数/hfmd（2010-2023）
##2.自变量为逐日平均温度/Tm
##3.混杂因素为时间趋势/time、平均相对湿度/Um、平均气压/Pm、降雨量/RRRa、平均风速/FFm和星期几效应/dow。
##4. 根据AIC准则选择自由度df，选择AIC值最小的df建立最终模型
#A.Pm、Tm的spearman相关系数＞0.7，不放入pm；
#B.hfmd、FFm的相关系数接近0且AIC结果指示，不放入FFm
#C.df = 3 * 7表示，时间变量的自由度为7/年，共有3年的数据

model_raw <- glm(hfmd~basis.tm + ns(time,11*7) 
              +ns(Um,3)+ ns(RRRa,3)+ns(FFm,3)#+ns(Pm,3) 
              + as.factor(dow) + as.factor(holiday2),
             family=quasipoisson(),data)#quasipoisson类泊松分布

##模型评价
#1：QAIC/QBIC[G,2010] 以QAIC为主
phi <- summary(model_raw)$dispersion
logll <- sum(dpois(ceiling(model_raw$y), lambda=exp(predict(model_raw)), log=TRUE))
QAIC<--2*logll + 2*summary(model_raw)$df[3]*phi
QAIC
QBIC<--2*logll + log(length(resid(model_raw)))*summary(model_raw)$df[3]*phi
QBIC

#------------------------------3.2修正模型--------------------------------------
##1.绘制残差图（无自回归项的模型）
#提取的残差向量
residuals <- resid(model_raw)
length(residuals)#n-lag=5113-21=5092

# 绘制残差的时间序列图
ggplot(data.frame(Time = 1:length(residuals), Residuals = residuals), aes(x = Time, y = Residuals)) +
  geom_line() +
  ggtitle("Residuals vs Time") +
  xlab("Time") +
  ylab("Residuals")
# 绘制残差的自相关函数（ACF）图
acf(residuals, main = "Autocorrelation Function of Residuals")
# 绘制残差的偏自相关函数（PACF）图
pacf(residuals, main = "Partial Autocorrelation Function of Residuals")


##2.构建残差滞后项
# 创建X阶滞后残差项，前21个值设为NA
# 这里假设滞后的时间窗口为21，如果需要不同的时间窗口，可以修改这个值
residuals <- resid(model_raw)
lag_window <- 22 #滞后期+1
n <- nrow(data)
data$lag_residuals <- c(rep(NA, lag_window), residuals[1:(n-lag_window)])


##3.重新建模
model <- glm(hfmd~basis.tm + ns(time,11*7) 
             + ns(RRRa,3) +ns(Um,3)+ns(FFm,3) #+ns(Pm,3) 
             + as.factor(dow) + as.factor(holiday2)
             + lag_residuals,
             family=quasipoisson(),data)#quasipoisson类泊松分布


phi <- summary(model)$dispersion
logll <- sum(dpois(ceiling(model$y), lambda=exp(predict(model)), log=TRUE))
QAIC<--2*logll + 2*summary(model)$df[3]*phi
QAIC
QBIC<--2*logll + log(length(resid(model)))*summary(model)$df[3]*phi
QBIC 

##4.重新绘制残差图
residuals <- resid(model)
length(residuals)#n-lag-阶数=5113-21-1=5091
# 绘制残差的自相关函数（ACF）图
acf(residuals, main = "Autocorrelation Function of Residuals")
# 绘制残差的偏自相关函数（PACF）图
pacf(residuals, main = "Partial Autocorrelation Function of Residuals")


#------------------------------4模型预测、导出参数-----------------------------
##0.目的：得到各个暴露值与滞后时间组合下对应的效应值。主要用到dlnm包中的crosspred()函数
##1.预测气温对应的效应（发病数）
##2.以气温中位数作为效应参考点
##3.气温对应的效应的95%CI、滞后天数×气温对应效应的95%CI
##[help:crosspred]
#A.matRRfit←matfit:所选预测变量和滞后值组合下的预测和标准误差矩阵
#B.allrrfit←allfit:总体累积预测关联和标准误差的向量
#C.cumrrfit←cumfit:所选预测变量和滞后值组合下，沿滞后的增量累积预测关联和相关标准误差的矩阵。cumul=TRUE

pred.tm <- crosspred(basis.tm, model,by=0.05,cumul=TRUE, #model_raw, #at = seq(0, 200, 1),#限定自变量范围
                     cen=median(data$Tm,na.rm=TRUE))##以温度中位数为参考温度，na.rm=TRUE表示剔除温度中的缺失值

names(pred.tm)#展示所拟合模型pred.tm内的变量，如allRRlow(95%CI下区间)

##2.气温-发病关系曲线，同原始反应曲线；温度(℃)"
plot(pred.tm,"overall",col=2,cex.axis=1.50,
     xlab="日平均气温（℃）",ylab="相对危险度",
     main="",cex.main=1.5)


#暴露-效应（所有滞后日的累积效应）
RR1 <- round(cbind(pred.tm$allRRfit,pred.tm$allRRlow,pred.tm$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm$matRRfit,pred.tm$matRRlow,pred.tm$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm$cumRRfit,pred.tm$cumRRlow,pred.tm$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm$predvar,RR1,RR2,RR3)

# 将结果导出到CSV文件
write.csv(rr_ci, "hfmd-tm-5y+.csv", row.names = FALSE)

#------------------------------5.结果可视化-------------------------------------
##0.使用plot()函数，它会调用dlnm包下的plot.corsspred()函数进行绘图
##1.3D图:全面展示效应随着暴露和滞后时间的变化情况
##2.Overall图:总的暴露反应图，即把各种暴露下所有滞后时间点对应的效应加和然后绘制暴露反应曲线
##3.滞后-反应图:以某个暴露值对3-D图进行切片，观察该暴露值下的效应随滞后时间的变化
##4.暴露-反应图:以某个滞后时间对3-D图进行切片，观察该滞后时间下的效应随滞后时间的变化
# cex.axis=1,调整坐标轴刻度标签的字体大小
# cex.lab=1,调整坐标轴标签的字体大小
# mgp = c(3, 1, 0)#无法调整用于调整3D图

##0.等高线图
plot(pred.tm,"contour",cex.axis=1.20,
     xlab="日平均气温（℃）",ylab="滞后时间（d）",
     main="",cex.main=1.5,cex.lab=1.2)

##1.3D图：温度与发病(默认蓝色)
plot(pred.tm, #col = "#00FF00",
     xlab = "
     日平均气温（℃）",#enter键竟然能增加坐标轴标题和轴之间的距离！
     ylab = "
     滞后时间（d）", 
     zlab = "
     相对危险度",
     )  


# ##2.气温-发病关系曲线(总体累积效应)
# plot(pred.tm,"overall",col=2,cex.axis=1.50,
#      xlab="日平均气温（℃）",ylab="相对危险度",
#      main="",cex.main=1.5,)



##3.1滞后-发病(P5/25/75/P95温度) 
plot(pred.tm, "slices", var=13.5, ci="n", col=1, lwd=1.5,ylim=c(0.9,1.2), 
     xlab="滞后时间（d）", ylab="相对危险度",main="≥5岁人群")
for(i in 1:3) lines(pred.tm, "slices", var=c(19.50,28.1,30.00)[i], col=i+1, lwd=1.5)
legend("topright",paste("日均温度 =",c(13.58,19.50,28.15,30.00),"℃"), col=1:4, lwd=1.5)


##3.2累积滞后-发病(P5/25/75/P95温度) 
plot(pred.tm, "slices", var=13.5, ci="n", col=1, lwd=1.5,ylim=c(0.7,3), 
     cumul=TRUE,
     xlab="滞后时间（d）", ylab="累积相对危险度")
for(i in 1:3) lines(pred.tm, "slices", var=c(19.50,28.1,30.00)[i], col=i+1, lwd=1.5,
                    cumul=TRUE)
legend("topleft",paste("日均温度 =",c(13.58,19.50,28.15,30.00),"℃"), col=1:4, lwd=1.5)



##4.气温-发病(滞后：7/14/21天)
plot(pred.tm, "slices", lag=7, ci="n", col=1, lwd=1.5,#ylim=c(0.9,1.1), 
     xlab="日均温度（℃）", ylab="相对危险度")
for(i in 1:3) lines(pred.tm, "slices", lag=c(10,14,21)[i], col=i+1, lwd=1.5)
legend("bottomright",paste("Lag =",c(7,10,14,21)), col=1:4, lwd=1.5)

#------------------------------待续---------------------------------------------
#Q1.var应该设什么值
#A1.by=0.5时，相对正常（var∈prevar时，正常运行plot）
##报错示例（by=0.01/0.05）
# > pred.tm$allRRfit["1002.4"]
# 1002.4 
# 1.05931 
#   >   lines(pred.tm, "slices", ci="bars", type="p", pch=19,ci.arg=list(col=i),
#             +         ci.level=0.95, var=1000.4, col=i, lwd=1.5)#Var必须是pred.tm内predvar的值?
# Error in lines.crosspred(pred.tm, "slices", ci = "bars", type = "p", pch = 19,  : 
#                            'var' must match values used for prediction


#Q2.同一图形展示不同亚组曲线（如男/女），如何令曲线稍微错开？
#A2.pred.tm$lag <- pred.tm$lag + shifts[i]
#错误1：在pred.tm内设置bylag的值→Y的值也发生改变
#错误2：Error in xy.coords(x, y) : 'x'和'y'的长度不一样→pred.tm无X/Y
#替代方案：不错开但调整透明度
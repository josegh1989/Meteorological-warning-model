pacman::p_load(dlnm,splines,psych,flexmix,ggplot2,ROCR,pscl,openxlsx)

##读取数据
data<-read.csv("D:\\zha\\DLNM\\SZ.csv")

#设置工作目录
setwd("D:\\zha\\DLNM")

variables000 <- c("H0y")
population_labels000 <- c("hfmd-0y") 

variables001 <- c("H1.5y")
population_labels001 <- c("hfmd-1-5y") 

variables002 <- c("H6.20y")
population_labels002 <- c("hfmd-6-20y") 

variables003 <- c("H.20y")
population_labels003 <- c("hfmd->20y") 

var_name000 <- variables000

basis.tm000 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw000 <- glm(get(var_name000) ~ basis.tm000 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals000 <- resid(model_raw000)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals000 <- c(rep(NA, lag_window), residuals000[1:(n - lag_window)])

model000 <- glm(get(var_name000) ~ basis.tm000 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals000,
                family = quasipoisson(), data = data)

pred.tm000 <- crosspred(basis.tm000, model000, by = 0.5, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#hfmd-age1-5
var_name001 <- variables001

basis.tm001 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw001 <- glm(get(var_name001) ~ basis.tm001 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals001 <- resid(model_raw001)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals001 <- c(rep(NA, lag_window), residuals001[1:(n - lag_window)])

model001 <- glm(get(var_name001) ~ basis.tm001 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals001,
                family = quasipoisson(), data = data)

pred.tm001 <- crosspred(basis.tm000, model000, by = 0.5, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#hfmd-age6-20
var_name002 <- variables002

basis.tm002 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw002 <- glm(get(var_name002) ~ basis.tm002 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals002 <- resid(model_raw002)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals002 <- c(rep(NA, lag_window), residuals002[1:(n - lag_window)])

model002 <- glm(get(var_name002) ~ basis.tm002 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals002,
                family = quasipoisson(), data = data)

pred.tm002 <- crosspred(basis.tm000, model000, by = 0.5, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))

#hfmd-age>20
var_name003 <- variables003

basis.tm003 <- crossbasis(data$Tm, lag=21,           
                          argvar=list(fun="ns",df=5),
                          arglag=list(knots=logknots(21,3)))

model_raw003 <- glm(get(var_name003) ~ basis.tm003 + ns(time, 11 * 7) + 
                      ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                      as.factor(dow) + as.factor(holiday2),
                    family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals003 <- resid(model_raw003)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals003 <- c(rep(NA, lag_window), residuals003[1:(n - lag_window)])

model003 <- glm(get(var_name003) ~ basis.tm003 + ns(time, 11 * 7) + 
                  ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                  as.factor(dow) + as.factor(holiday2) + lag_residuals003,
                family = quasipoisson(), data = data)
pred.tm003 <- crosspred(basis.tm000, model000, by = 0.5, cumul = TRUE,
                        cen = median(data$Tm, na.rm = TRUE))


pred_0y <- pred.tm000$cumRRfit  # hfmd-0y
pred_1_5y <- pred.tm001$cumRRfit  # hfmd-1-5y
pred_6_20y <- pred.tm002$cumRRfit  # hfmd-6-20y
pred_over_20y <- pred.tm003$cumRRfit  # hfmd->20y

pred_0ylow <- pred.tm000$cumRRlow  # hfmd-0y
pred_1_5ylow <- pred.tm001$cumRRlow  # hfmd-1-5y
pred_6_20ylow <- pred.tm002$cumRRlow  # hfmd-6-20y
pred_over_20ylow <- pred.tm003$cumRRlow  # hfmd->20y

pred_0yhigh <- pred.tm000$cumRRhigh  # hfmd-0y
pred_1_5yhigh <- pred.tm001$cumRRhigh  # hfmd-1-5y
pred_6_20yhigh <- pred.tm002$cumRRhigh  # hfmd-6-20y
pred_over_20yhigh <- pred.tm003$cumRRhigh  # hfmd->20y

ref_fit <- pred_over_20y
ref_low <- pred_over_20ylow
ref_high <- pred_over_20yhigh

fixed_lag <- 1  # lag1
fixed_tm <- 25   # Tm值为4

# 提取 cumRRfit
# 注意：lag 是从0开始的索引，所以 lag1 在 R 中对应于索引1
cumRRfit_value <- pred.tm000$cumRRfit[ , fixed_lag][as.numeric(names(pred.tm000$cumRRfit[, fixed_lag]) == as.character(fixed_tm))]

# 输出结果
print(cumRRfit_value)


# 计算RR和置信区间
rr_0y <- pred_0y / ref_fit
rr_1_5y <- pred_1_5y / ref_fit
rr_6_20y <- pred_6_20y / ref_fit

rr_0ylow <- pred_0ylow / ref_fit
rr_1_5ylow <- pred_1_5ylow / ref_fit
rr_6_20ylow <- pred_6_20ylow / ref_fit

rr_0yhigh <- pred_0yhigh / ref_fit
rr_1_5yhigh <- pred_1_5yhigh / ref_fit
rr_6_20yhigh <- pred_6_20yhigh / ref_fit

# 将结果合并到数据框中
results <- data.frame(
  Group = c("0y", "1-5y", "6-20y"),
  RR = c(rr_0y, rr_1_5y, rr_6_20y),
  CI_low = c(rr_0ylow, rr_1_5ylow, rr_6_20ylow),
  CI_high = c(rr_0yhigh, rr_1_5yhigh, rr_6_20yhigh)
)

# 显示结果
print(results)

library(openxlsx)

# 计算RR和置信区间（假设前面的代码已经执行）
# ... (前面的代码)

# 将结果保存到Excel文件
write.xlsx(results, "RR_results.xlsx", rowNames = FALSE)





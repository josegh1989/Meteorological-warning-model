pacman::p_load(dlnm,splines,psych,flexmix,ggplot2,ROCR,pscl,openxlsx)
#---1.加season变量----
##读取数据
data<-read.csv("D:\\zha\\DLNM\\SZ1.csv")

#设置工作目录
setwd("D:\\zha\\DLNM")

#-----变量-----
#总
variables0 <- c("hfmd")
population_labels0 <- c("hfmd-All") 
variables1 <- c("DV")
population_labels1 <- c("DV-All")
variables2 <- c("DN")
population_labels2 <- c("DN-All") 

#HFMDALL
var_name0 <- variables0

# 构建原始模型（暴露因素选择Tm/Pm2）
basis.tm0 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=5),
                        arglag=list(knots=logknots(21,3)))

model_raw0 <- glm(get(var_name0) ~ basis.tm0 + ns(time, 11 * 7) + 
                    ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2) + as.factor(season),
                  family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals <- resid(model_raw0)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals0 <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])

model0 <- glm(get(var_name0) ~ basis.tm0 + ns(time, 11 * 7) + 
                ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + as.factor(season) + lag_residuals0,
              family = quasipoisson(), data = data)

pred.tm0 <- crosspred(basis.tm0, model0, by = 0.5, cumul = TRUE,
                      cen = median(data$Tm, na.rm = TRUE))

#DVAll
var_name1 <- variables1

basis.tm1 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=4),
                        arglag=list(knots=logknots(21,5)))

model_raw1 <- glm(get(var_name1) ~ basis.tm1 + ns(time, 11 * 7) + 
                    ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

residuals1 <- resid(model_raw1)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals1 <- c(rep(NA, lag_window), residuals1[1:(n - lag_window)])

model1 <- glm(get(var_name1) ~ basis.tm1 + ns(time, 11 * 7) + 
                ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals1,
              family = quasipoisson(), data = data)

pred.tm1 <- crosspred(basis.tm1, model1, by = 0.5, cumul = TRUE,
                      cen = median(data$Tm, na.rm = TRUE))

#DNALL
var_name2 <- variables2

basis.tm2 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=4),
                        arglag=list(knots=logknots(21,3)))

model_raw2 <- glm(get(var_name2) ~ basis.tm2 + ns(time, 11 * 7) + 
                    ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

residuals2 <- resid(model_raw2)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals2 <- c(rep(NA, lag_window), residuals2[1:(n - lag_window)])

model2 <- glm(get(var_name2) ~ basis.tm2 + ns(time, 11 * 7) + 
                ns(RRRa, 3) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals2,
              family = quasipoisson(), data = data)

pred.tm2 <- crosspred(basis.tm2, model2, by = 0.5, cumul = TRUE,
                      cen = median(data$Tm, na.rm = TRUE))

wb <- createWorkbook()
RR1 <- round(cbind(pred.tm0$allRRfit,pred.tm0$allRRlow,pred.tm0$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm0$matRRfit,pred.tm0$matRRlow,pred.tm0$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm0$cumRRfit,pred.tm0$cumRRlow,pred.tm0$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm0$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb, paste0("", var_name0))
writeData(wb, sheet = paste0("", var_name0), rr_ci)



# 保存工作簿到CSV文件
saveWorkbook(wb, "hfmd-SZ-S.xlsx", overwrite = TRUE)

wb <- createWorkbook()
RR1 <- round(cbind(pred.tm1$allRRfit,pred.tm1$allRRlow,pred.tm1$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm1$matRRfit,pred.tm1$matRRlow,pred.tm1$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm1$cumRRfit,pred.tm1$cumRRlow,pred.tm1$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm1$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb, paste0("", var_name1))
writeData(wb, sheet = paste0("", var_name1), rr_ci)



# 保存工作簿到CSV文件
saveWorkbook(wb, "DV-SZ-S.xlsx", overwrite = TRUE)

wb <- createWorkbook()
RR1 <- round(cbind(pred.tm2$allRRfit,pred.tm2$allRRlow,pred.tm2$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm2$matRRfit,pred.tm2$matRRlow,pred.tm2$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm2$cumRRfit,pred.tm2$cumRRlow,pred.tm2$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm2$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb, paste0("", var_name2))
writeData(wb, sheet = paste0("", var_name2), rr_ci)



# 保存工作簿到CSV文件
saveWorkbook(wb, "DN-SZ-S.xlsx", overwrite = TRUE)

#---2.半年为单位（春夏，秋冬）----
data<-read.csv("D:\\zha\\DLNM\\SZA.csv")
data<-read.csv("D:\\zha\\DLNM\\SZS.csv")
#设置工作目录
setwd("D:\\zha\\DLNM")

#-----变量-----
#总
variables0 <- c("hfmd")
population_labels0 <- c("hfmd-All") 
variables00 <- c("hfmd")
population_labels00 <- c("hfmd-All") 

variables1 <- c("DV")
population_labels1 <- c("DV-All")
variables01 <- c("DV")
population_labels01 <- c("DV-All")

variables2 <- c("DN")
population_labels2 <- c("DN-All") 
variables02 <- c("DN")
population_labels02 <- c("DN-All")

#----hfmdA----
var_name0 <- variables0

basis.tm0 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=5),
                        arglag=list(knots=logknots(21,4)))

model_raw0 <- glm(get(var_name0) ~ basis.tm0 + ns(time, 12 * 7) + 
                    ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals <- resid(model_raw0)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals0 <- c(rep(NA, lag_window), residuals[1:(n - lag_window)])

model0 <- glm(get(var_name0) ~ basis.tm0 + ns(time, 12 * 7) + 
                ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals0,
              family = quasipoisson(), data = data)

pred.tm0 <- crosspred(basis.tm0, model0, by = 0.5, cumul = TRUE,
                      cen = 24.74)
#----hfmdS----
var_name00 <- variables00

basis.tm00 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,4)))

model_raw00 <- glm(get(var_name00) ~ basis.tm00 + ns(time, 12 * 7) + 
                     ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals00 <- resid(model_raw00)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals00 <- c(rep(NA, lag_window), residuals00[1:(n - lag_window)])

model00 <- glm(get(var_name00) ~ basis.tm00 + ns(time, 12 * 7) + 
                 ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals00,
               family = quasipoisson(), data = data)

pred.tm00 <- crosspred(basis.tm00, model00, by = 0.5, cumul = TRUE,
                       cen = 24.74)

wb0 <- createWorkbook()
RR1 <- round(cbind(pred.tm0$allRRfit,pred.tm0$allRRlow,pred.tm0$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm0$matRRfit,pred.tm0$matRRlow,pred.tm0$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm0$cumRRfit,pred.tm0$cumRRlow,pred.tm0$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm0$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb0, paste0("", var_name0))
writeData(wb0, sheet = paste0("", var_name0), rr_ci)

wb00 <- createWorkbook()
RR1 <- round(cbind(pred.tm00$allRRfit,pred.tm00$allRRlow,pred.tm00$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm00$matRRfit,pred.tm00$matRRlow,pred.tm00$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm00$cumRRfit,pred.tm00$cumRRlow,pred.tm00$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm00$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb00, paste0("", var_name00))
writeData(wb00, sheet = paste0("", var_name00), rr_ci)

# 保存工作簿到CSV文件
saveWorkbook(wb0, "hfmd-SZ-AS.xlsx", overwrite = TRUE)
saveWorkbook(wb00, "hfmd-SZ-SS.xlsx", overwrite = TRUE)


#----DVA----

var_name1 <- variables1

basis.tm1 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=4),
                        arglag=list(knots=logknots(21,4)))

model_raw1 <- glm(get(var_name1) ~ basis.tm1 + ns(time, 12 * 7) + 
                    ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

residuals1 <- resid(model_raw1)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals1 <- c(rep(NA, lag_window), residuals1[1:(n - lag_window)])

model1 <- glm(get(var_name1) ~ basis.tm1 + ns(time, 12 * 7) + 
                ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals1,
              family = quasipoisson(), data = data)

pred.tm1 <- crosspred(basis.tm1, model1, by = 0.5, cumul = TRUE,
                      cen = 24.74)

#----DVS----
var_name01 <- variables01

basis.tm01 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=4),
                         arglag=list(knots=logknots(21,4)))

model_raw01 <- glm(get(var_name01) ~ basis.tm01 + ns(time, 12 * 7) + 
                     ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals01 <- resid(model_raw01)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals01 <- c(rep(NA, lag_window), residuals01[1:(n - lag_window)])

model01 <- glm(get(var_name01) ~ basis.tm01 + ns(time, 12 * 7) + 
                 ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals01,
               family = quasipoisson(), data = data)

pred.tm01 <- crosspred(basis.tm01, model01, by = 0.5, cumul = TRUE,
                       cen = 24.74)

wb1 <- createWorkbook()
RR1 <- round(cbind(pred.tm1$allRRfit,pred.tm1$allRRlow,pred.tm1$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm1$matRRfit,pred.tm1$matRRlow,pred.tm1$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm1$cumRRfit,pred.tm1$cumRRlow,pred.tm1$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm1$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb1, paste0("", var_name1))
writeData(wb1, sheet = paste0("", var_name1), rr_ci)

wb01 <- createWorkbook()
RR1 <- round(cbind(pred.tm01$allRRfit,pred.tm01$allRRlow,pred.tm01$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm01$matRRfit,pred.tm01$matRRlow,pred.tm01$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm01$cumRRfit,pred.tm01$cumRRlow,pred.tm01$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm01$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb01, paste0("", var_name01))
writeData(wb01, sheet = paste0("", var_name01), rr_ci)

# 保存工作簿到CSV文件
saveWorkbook(wb1, "DV-SZ-AS.xlsx", overwrite = TRUE)
saveWorkbook(wb01, "DV-SZ-SS.xlsx", overwrite = TRUE)

#----DNA----
var_name2 <- variables2

basis.tm2 <- crossbasis(data$Tm, lag=21,           
                        argvar=list(fun="ns",df=4),
                        arglag=list(knots=logknots(21,3)))

model_raw2 <- glm(get(var_name2) ~ basis.tm2 + ns(time, 12 * 7) + 
                    ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                    as.factor(dow) + as.factor(holiday2),
                  family = quasipoisson(), data = data)

residuals2 <- resid(model_raw2)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals2 <- c(rep(NA, lag_window), residuals2[1:(n - lag_window)])

model2 <- glm(get(var_name2) ~ basis.tm2 + ns(time, 12 * 7) + 
                ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                as.factor(dow) + as.factor(holiday2) + lag_residuals2,
              family = quasipoisson(), data = data)

pred.tm2 <- crosspred(basis.tm2, model2, by = 0.5, cumul = TRUE,
                      cen = 24.74)
#----DNS----
var_name02 <- variables02

basis.tm02 <- crossbasis(data$Tm, lag=21,           
                         argvar=list(fun="ns",df=5),
                         arglag=list(knots=logknots(21,4)))

model_raw02 <- glm(get(var_name02) ~ basis.tm02 + ns(time, 13 * 7) + 
                     ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                     as.factor(dow) + as.factor(holiday2),
                   family = quasipoisson(), data = data)

# 构建包含滞后残差的新模型
residuals02 <- resid(model_raw02)
lag_window <- 22  # 滞后期+1
n <- nrow(data)  # 确保数据集的行数是数值类型
data$lag_residuals02 <- c(rep(NA, lag_window), residuals02[1:(n - lag_window)])

model02 <- glm(get(var_name02) ~ basis.tm02 + ns(time, 13 * 7) + 
                 ns(RRRa, 1) + ns(Um, 3) + ns(FFm, 3) + 
                 as.factor(dow) + as.factor(holiday2) + lag_residuals02,
               family = quasipoisson(), data = data)

pred.tm02 <- crosspred(basis.tm02, model02, by = 0.5, cumul = TRUE,
                       cen = 24.74)

wb2 <- createWorkbook()
RR1 <- round(cbind(pred.tm2$allRRfit,pred.tm2$allRRlow,pred.tm2$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm2$matRRfit,pred.tm2$matRRlow,pred.tm2$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm2$cumRRfit,pred.tm2$cumRRlow,pred.tm2$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm2$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb2, paste0("", var_name2))
writeData(wb2, sheet = paste0("", var_name2), rr_ci)

wb02 <- createWorkbook()
RR1 <- round(cbind(pred.tm02$allRRfit,pred.tm02$allRRlow,pred.tm02$allRRhigh),digits=3)
#暴露-滞后-效应（某一天的当日滞后效应）
RR2 <- round(cbind(pred.tm02$matRRfit,pred.tm02$matRRlow,pred.tm02$matRRhigh),digits=3)
#暴露-滞后-效应（某一天的累积滞后效应）
RR3 <- round(cbind(pred.tm02$cumRRfit,pred.tm02$cumRRlow,pred.tm02$cumRRhigh),digits=3)
# 创建一个数据框来存储参数名称、估计值、95% CI下限和上限
rr_ci <- data.frame(pred.tm02$predvar,RR1,RR2,RR3)

# 将结果添加到工作簿的工作表中
addWorksheet(wb02, paste0("", var_name02))
writeData(wb02, sheet = paste0("", var_name02), rr_ci)

# 保存工作簿到CSV文件
saveWorkbook(wb2, "DN-SZ-AS.xlsx", overwrite = TRUE)
saveWorkbook(wb02, "DN-SZ-SS.xlsx", overwrite = TRUE)


#----qaic/qbic-----
qaicbic <- function(model_raw02) {
  phi <- summary(model_raw02)$dispersion
  logll <- sum(dpois(ceiling(model_raw02$y), lambda=exp(predict(model_raw02)), log=TRUE))
  c(AIC=-2*logll + 2*summary(model_raw02)$df[3]*phi,
    BIC=-2*logll + log(length(resid(model_raw02)))*phi*summary(model_raw02)$df[3])
}

tqba <- data.frame()
for (ii in 3:6) {
  for (jj in 3:6) {
    for (kk in 10:13){
    basis.tm <- crossbasis(data$Tm, lag=21,
                           argvar=list(fun="ns",df=ii),
                           arglag=list(knots=logknots(21,jj)))
    model_raw02 <- glm(hfmd~basis.tm + ns(time,kk*7) 
                     + ns(RRRa,1)+ns(FFm,3)+ns(Um,3)
                     + as.factor(holiday2)+ as.factor(dow),
                     family=quasipoisson(),data)
    
    residuals <- resid(model_raw02)
    acf_result <- acf(residuals, plot = FALSE)  # 使用acf函数计算自相关系数和偏自相关系数
    pacf_values <- acf_result$acf[-1]  # pacf函数的输出中，偏自相关系数从第二个值开始
    sum_of_paac <- sum(abs(pacf_values))  # 计算偏自相关系数之和
    
    # 输出模型摘要，这里可以注释掉，因为它不会影响输出结果
    # summary(model_raw)
    
    # 将结果绑定到数据框中
    q <- data.frame(ii=ii, jj=jj, kk,
                    QAIC=qaicbic(model_raw02)[1], QBIC=qaicbic(model_raw02)[2], 
                    sum_of_paac=sum_of_paac)
    tqba <- rbind(tqba, q)
    }
  }
}

print(tqba)
# 找出tqba中各个变量的最小值
min_values <- apply(tqba, 2, function(x) min(x, na.rm = TRUE))
print(min_values)

#----作图----
install.packages("plotly")

library(plotly)

DN_AS<-read.csv("D:/zha/DLNM/season/plotly/DN-AS.csv")
# 创建数据框
data2 <- data.frame(
  x = DN_AS$Tm,
  y = DN_AS$Lagdays,
  z = DN_AS$CumulativeRR,
  group = as.factor(DN_AS$meaning)
  )  # 分组信息


# 绘制3D散点图
levels(data2$group) <- c("Significant", "Insignificant")
colors <- c("red", "blue")
fig01 <- plot_ly(data2, x = ~x, y = ~y, z = ~z, color = ~group, 
                colors = colors, type = 'scatter3d', mode = 'markers', marker = list(size = 1))

# 修改坐标轴名称
fig01 <- fig01 %>% layout(
  scene = list(
    xaxis = list(title = 'Tm'),
    yaxis = list(title = 'Lagdays'),
    zaxis = list(title = 'Cumulative RR')
  )
)

# 调整图例和添加额外的“group”标签
fig01 <- fig01 %>% layout(
  legend = list(
    font = list(size = 14),    # 增大字体大小
    bordercolor = 'black',     # 边框颜色
    borderwidth = 2,           # 边框宽度
    bgcolor = 'white',     # 背景颜色
    xanchor = 'right',         # 图例水平位置
    yanchor = 'top',           # 图例垂直位置
    x = 1.1,                   # 水平位置偏移
    y = 0.9 ,                  # 垂直位置偏移
    marker = list(size = 20)   # 设置图例中点的大小
  ),    
  annotations = list(
    list(
      x = 1.1,                     # 水平位置
      y = 0.95,                    # 垂直位置
      text = "Meaningful",          # 额外标签的内容
      showarrow = FALSE,           # 不显示箭头
      xref = "paper",              # 相对纸张位置
      yref = "paper",              # 相对纸张位置
      font = list(size = 16, color = "black")  # 标签字体大小和颜色
    )
  )
)
# 显示图形
fig01

DN_SS<-read.csv("D:/zha/DLNM/season/plotly/DN-SS.csv")
# 创建数据框
data2 <- data.frame(
  x = DN_SS$Tm,
  y = DN_SS$Lagdays,
  z = DN_SS$CumulativeRR,
  group = as.factor(DN_SS$meaning)
)  # 分组信息


# 绘制3D散点图
levels(data2$group) <- c("Insignificant", "Significant")
colors <- c("darkgreen", "red")
fig02 <- plot_ly(data2, x = ~x, y = ~y, z = ~z, color = ~group, 
                 colors = colors, type = 'scatter3d', mode = 'markers', marker = list(size = 1))

# 修改坐标轴名称
fig02 <- fig02 %>% layout(
  scene = list(
    xaxis = list(title = 'Tm'),
    yaxis = list(title = 'Lagdays'),
    zaxis = list(title = 'Cumulative RR')
  )
)

# 调整图例和添加额外的“group”标签
fig02 <- fig02 %>% layout(
  legend = list(
    font = list(size = 14),    # 增大字体大小
    bordercolor = 'black',     # 边框颜色
    borderwidth = 2,           # 边框宽度
    bgcolor = 'white',     # 背景颜色
    xanchor = 'right',         # 图例水平位置
    yanchor = 'top',           # 图例垂直位置
    x = 1.1,                   # 水平位置偏移
    y = 0.9                    # 垂直位置偏移
  ),
  annotations = list(
    list(
      x = 1.1,                     # 水平位置
      y = 0.95,                    # 垂直位置
      text = "Meaningful",          # 额外标签的内容
      showarrow = FALSE,           # 不显示箭头
      xref = "paper",              # 相对纸张位置
      yref = "paper",              # 相对纸张位置
      font = list(size = 16, color = "black")  # 标签字体大小和颜色
    )
  )
)
# 显示图形
fig02

DV_AS<-read.csv("D:/zha/DLNM/season/plotly/DV-AS.csv")
# 创建数据框
data2 <- data.frame(
  x = DV_AS$Tm,
  y = DV_AS$Lagdays,
  z = DV_AS$CumulativeRR,
  group = as.factor(DV_AS$meaning)
)  # 分组信息


# 绘制3D散点图
levels(data2$group) <- c("Insignificant", "Significant")
colors <- c("blue", "red")
fig03 <- plot_ly(data2, x = ~x, y = ~y, z = ~z, color = ~group, 
                 colors = colors, type = 'scatter3d', mode = 'markers', marker = list(size = 1))

# 修改坐标轴名称
fig03 <- fig03 %>% layout(
  scene = list(
    xaxis = list(title = 'Tm'),
    yaxis = list(title = 'Lagdays'),
    zaxis = list(title = 'Cumulative RR')
  )
)

# 调整图例和添加额外的“group”标签
fig03 <- fig03 %>% layout(
  legend = list(
    font = list(size = 14),    # 增大字体大小
    bordercolor = 'black',     # 边框颜色
    borderwidth = 2,           # 边框宽度
    bgcolor = 'white',     # 背景颜色
    xanchor = 'right',         # 图例水平位置
    yanchor = 'top',           # 图例垂直位置
    x = 1.1,                   # 水平位置偏移
    y = 0.9                    # 垂直位置偏移
  ),
  annotations = list(
    list(
      x = 1.1,                     # 水平位置
      y = 0.95,                    # 垂直位置
      text = "Meaningful",          # 额外标签的内容
      showarrow = FALSE,           # 不显示箭头
      xref = "paper",              # 相对纸张位置
      yref = "paper",              # 相对纸张位置
      font = list(size = 16, color = "black")  # 标签字体大小和颜色
    )
  )
)
# 显示图形
fig03

DV_SS<-read.csv("D:/zha/DLNM/season/plotly/DV-SS.csv")
# 创建数据框
data2 <- data.frame(
  x = DV_SS$Tm,
  y = DV_SS$Lagdays,
  z = DV_SS$CumulativeRR,
  group = as.factor(DV_SS$meaning)
)  # 分组信息


# 绘制3D散点图
levels(data2$group) <- c("Insignificant", "Significant")
colors <- c("darkgreen", "red")
fig04 <- plot_ly(data2, x = ~x, y = ~y, z = ~z, color = ~group, 
                 colors = colors, type = 'scatter3d', mode = 'markers', marker = list(size = 1))

# 修改坐标轴名称
fig04 <- fig04 %>% layout(
  scene = list(
    xaxis = list(title = 'Tm'),
    yaxis = list(title = 'Lagdays'),
    zaxis = list(title = 'Cumulative RR')
  )
)

# 调整图例和添加额外的“group”标签
fig04 <- fig04 %>% layout(
  legend = list(
    font = list(size = 14),    # 增大字体大小
    bordercolor = 'black',     # 边框颜色
    borderwidth = 2,           # 边框宽度
    bgcolor = 'white',     # 背景颜色
    xanchor = 'right',         # 图例水平位置
    yanchor = 'top',           # 图例垂直位置
    x = 1.1,                   # 水平位置偏移
    y = 0.9                    # 垂直位置偏移
  ),
  annotations = list(
    list(
      x = 1.1,                     # 水平位置
      y = 0.95,                    # 垂直位置
      text = "Meaningful",          # 额外标签的内容
      showarrow = FALSE,           # 不显示箭头
      xref = "paper",              # 相对纸张位置
      yref = "paper",              # 相对纸张位置
      font = list(size = 16, color = "black")  # 标签字体大小和颜色
    )
  )
)
# 显示图形
fig04


HFMD_AS<-read.csv("D:/zha/DLNM/season/plotly/HFMD-AS.csv")
# 创建数据框
data2 <- data.frame(
  x = HFMD_AS$Tm,
  y = HFMD_AS$Lagdays,
  z = HFMD_AS$CumulativeRR,
  group = as.factor(HFMD_AS$meaning)
)  # 分组信息


# 绘制3D散点图
levels(data2$group) <- c("Insignificant", "Significant")
colors <- c("blue", "red")
fig05 <- plot_ly(data2, x = ~x, y = ~y, z = ~z, color = ~group, 
                 colors = colors, type = 'scatter3d', mode = 'markers', marker = list(size = 1))

# 修改坐标轴名称
fig05 <- fig05 %>% layout(
  scene = list(
    xaxis = list(title = 'Tm'),
    yaxis = list(title = 'Lagdays'),
    zaxis = list(title = 'Cumulative RR')
  )
)

# 调整图例和添加额外的“group”标签
fig05 <- fig05 %>% layout(
  legend = list(
    font = list(size = 14),    # 增大字体大小
    bordercolor = 'black',     # 边框颜色
    borderwidth = 2,           # 边框宽度
    bgcolor = 'white',     # 背景颜色
    xanchor = 'right',         # 图例水平位置
    yanchor = 'top',           # 图例垂直位置
    x = 1.1,                   # 水平位置偏移
    y = 0.9                    # 垂直位置偏移
  ),
  annotations = list(
    list(
      x = 1.1,                     # 水平位置
      y = 0.95,                    # 垂直位置
      text = "Meaningful",          # 额外标签的内容
      showarrow = FALSE,           # 不显示箭头
      xref = "paper",              # 相对纸张位置
      yref = "paper",              # 相对纸张位置
      font = list(size = 16, color = "black")  # 标签字体大小和颜色
    )
  )
)
# 显示图形
fig05

HFMD_SS<-read.csv("D:/zha/DLNM/season/plotly/HFMD-SS.csv")
# 创建数据框
data2 <- data.frame(
  x = HFMD_SS$Tm,
  y = HFMD_SS$Lagdays,
  z = HFMD_SS$CumulativeRR,
  group = as.factor(HFMD_SS$meaning)
)  # 分组信息


# 绘制3D散点图
levels(data2$group) <- c("Insignificant", "Significant")
colors <- c("darkgreen", "red")
fig06 <- plot_ly(data2, x = ~x, y = ~y, z = ~z, color = ~group, 
                 colors = colors, type = 'scatter3d', mode = 'markers', marker = list(size = 1))

# 修改坐标轴名称
fig06 <- fig06 %>% layout(
  scene = list(
    xaxis = list(title = 'Tm'),
    yaxis = list(title = 'Lagdays'),
    zaxis = list(title = 'Cumulative RR')
  )
)

# 调整图例和添加额外的“group”标签
fig06 <- fig06 %>% layout(
  legend = list(
    font = list(size = 14),    # 增大字体大小
    bordercolor = 'black',     # 边框颜色
    borderwidth = 2,           # 边框宽度
    bgcolor = 'white',     # 背景颜色
    xanchor = 'right',         # 图例水平位置
    yanchor = 'top',           # 图例垂直位置
    x = 1.1,                   # 水平位置偏移
    y = 0.9                    # 垂直位置偏移
  ),
  annotations = list(
    list(
      x = 1.1,                     # 水平位置
      y = 0.95,                    # 垂直位置
      text = "Meaningful",          # 额外标签的内容
      showarrow = FALSE,           # 不显示箭头
      xref = "paper",              # 相对纸张位置
      yref = "paper",              # 相对纸张位置
      font = list(size = 16, color = "black")  # 标签字体大小和颜色
    )
  )
)
# 显示图形
fig06

#----作图overall----
tiff(filename = "Season-OVERALL.tiff", width = 9, height = 3, units = "in", res = 600)
#png(filename = "Tm-OVERALL.png", width = 8, height = 3, units = "in", res = 600)
# 设置图形布局参数

par(mfrow = c(1, 3))#3行张图,宽：高=8:3 

plot(pred.tm0, ptype="overall", ci="area", col="blue", lwd = 2, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Temperature(℃)", ylab = "Cumulative RR(95%CI)",  main = "HFMD"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm00, ptype="overall", ci="area", lwd = 2, lty = 2, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("topleft", legend=c("A-W", "S-S"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)
#DV
plot(pred.tm1, ptype="overall", ci="area", col="blue", lwd = 2, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Temperature(℃)", ylab = "Cumulative RR(95%CI)", 
     main = "DV"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm01, ptype="overall", ci="area", lwd = 2, lty = 2, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("topright", legend=c("A-W", "S-S"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)

#DN
plot(pred.tm2, ptype="overall", ci="area", col="blue", lwd = 2, ci.arg=list(col=rgb(0,0,1,0.25)), xlab = "Temperature(℃)", ylab = "Cumulative RR(95%CI)", 
     ylim=c(0,8), main = "DN"  )

# 保持当前图形，添加第二个预测结果及其置信区间
lines(pred.tm02, ptype="overall", ci="area", lwd = 2, lty = 2, col="#D95316", ci.arg=list(col=rgb(1,0.3,0.1,0.15)))

# 如果您想要为置信区间添加不同的颜色和透明度，可以通过修改plot函数中的ci.arg参数来实现
# 例如，为第二个预测结果的置信区间添加阴影参数
legend("topright", legend=c("A-W", "S-S"), col=c("blue", "#D95316"), lty=c(1, 2), bty = "n",
       inset=0.05, cex=0.8, y.intersp=0.85)


dev.off()


